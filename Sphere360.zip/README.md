# Sphere 360 (v0.2.0)

Records the front and rear cameras of an Android phone at the same time and lets you
look around the result as a 360 sphere. Works with no lens (partial sphere) or with
fisheye clip-on lenses on both cameras (full sphere when each lens covers more than 180 degrees).

## Build on GitHub (no computer needed)
1. Create a new GitHub repository and upload everything in this ZIP (keep the `.github` folder).
2. Open the **Actions** tab. The "Build APK" workflow runs on every upload.
3. When it turns green, open the run and download **Sphere360-debug-apk**.
4. Install the APK on the phone (allow installs from your browser or files app).

If the build fails, open the failed step and copy the red error lines.

## What works in this version
- Camera check screen: reads what the phone really supports and gives a copyable report.
- Dual recording with Camera2 concurrent sessions: one MP4 per camera, sound on the rear file.
- Live fps and dropped-frame counts measured from real camera timestamps.
- Auto-stop on storage limit, overheating, or your chosen time limit. Recording stops and saves when the app goes to the background.
- 360 player: drag to look, pinch to zoom, "Move phone" to look around with the motion sensor, recenter.
- Real coverage number, computed from the lens geometry (no invented percentages).
- Adjust panel: turn each view, mirror front, fisheye lens angle, circle size, seam softness. Saved per recording.
- Save 360 photo: exports the current frame as a 4096x2048 equirectangular JPEG with Photo Sphere metadata.

## New in 0.2.0
- Room scan: stand where you'll record, turn slowly around, and the app paints a real 360 photo
  of the room using the camera and the phone's orientation sensor. Saved as a 360 photo in Photos too.
- Recordings use the latest room scan to fill everything the cameras didn't see.
- Horizon leveling: the phone orientation at the start of recording is saved, so the view stays level,
  and holding the phone sideways (landscape) works.
- Soft edges between video and fill, and a "Soft fill" option when there's no room scan.
- Adjust panel: choose Room photo, Soft fill or Grid, turn the room photo to line it up, level horizon on/off.

## Known limits (honest list)
- The room photo is still. Only the two camera views move.
- Room photo and video line up using the compass, which can be off indoors. Use "Turn room photo" to fix it.
- If the scan picture looks sideways, tap "Picture sideways?" on the scan screen.
- Without lenses, two phone cameras cover roughly 30% of the sphere. The rest is shown as a grid.
- Exporting a full 360 **video** file (for YouTube) is not in this version yet. Planned for v0.2.
- Fisheye lenses need calibration in the Adjust panel the first time.
- The two cameras sit in different places on the phone, so close objects near the seam may not line up.
- Not tested on a real device by the developer. Needs testing on the Galaxy S24 Ultra.
- Recording runs only while the app is open (no background recording).

## Unit tests
`gradle testDebugUnitTest` runs the sphere geometry tests (coverage math).
