package com.ayman.sphere360.geometry

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SphereGridTest {
    private val identity = floatArrayOf(1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f)
    private val lens = SphereMath.lensFor(100f, 1000, 1000, 0f, 1f)

    @Test
    fun markingOneViewCoversPartOfSphere() {
        val g = SphereGrid()
        g.mark(identity, lens)
        val f = g.fraction()
        assertTrue("fraction was $f", f > 0.05f && f < 0.3f)
    }

    @Test
    fun resetClearsCoverage() {
        val g = SphereGrid()
        g.mark(identity, lens)
        g.reset()
        assertEquals(0f, g.fraction(), 0.0001f)
    }
}
