package com.ayman.sphere360.geometry

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SphereMathTest {

    @Test
    fun twoFisheyeLensesWiderThan180CoverWholeSphere() {
        val lens = SphereMath.lensFor(hFovDeg = 90f, width = 1000, height = 1000, rotDeg = 0f, circleScale = 1f)
        val c = SphereMath.coverage(lens, lens, fisheye = true, halfFovRad = Math.toRadians(100.0), mirrorFront = false)
        assertTrue("coverage was $c", c > 0.99f)
    }

    @Test
    fun fisheyeLensesNarrowerThan180LeaveAGap() {
        val lens = SphereMath.lensFor(90f, 1000, 1000, 0f, 1f)
        val c = SphereMath.coverage(lens, lens, fisheye = true, halfFovRad = Math.toRadians(80.0), mirrorFront = false)
        assertTrue("coverage was $c", c < 0.99f)
    }

    @Test
    fun normalPhoneCamerasCoverRoughlyAThird() {
        // Rear ultra-wide about 120 degrees, front about 80 degrees, 16:9 video
        val rear = SphereMath.lensFor(120f, 1920, 1080, 90f, 1f)
        val front = SphereMath.lensFor(80f, 1920, 1080, 270f, 1f)
        val c = SphereMath.coverage(rear, front, fisheye = false, halfFovRad = 0.0, mirrorFront = false)
        assertTrue("coverage was $c", c in 0.2f..0.4f)
    }

    @Test
    fun rotationDoesNotChangeCoverageOfSquareLens() {
        val a = SphereMath.lensFor(90f, 1000, 1000, 0f, 1f)
        val b = SphereMath.lensFor(90f, 1000, 1000, 90f, 1f)
        val ca = SphereMath.coverage(a, a, false, 0.0, false)
        val cb = SphereMath.coverage(b, b, false, 0.0, false)
        assertEquals(ca, cb, 0.01f)
    }

    @Test
    fun pointStraightAheadIsCoveredByRearCamera() {
        val lens = SphereMath.lensFor(80f, 1920, 1080, 90f, 1f)
        assertTrue(SphereMath.covered(0.0, 0.0, 1.0, lens, false, 0.0))
    }
}
