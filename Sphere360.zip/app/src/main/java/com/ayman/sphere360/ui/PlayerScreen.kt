package com.ayman.sphere360.ui

import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.opengl.GLSurfaceView
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.Panorama
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Rotate90DegreesCw
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.ayman.sphere360.data.Calibration
import com.ayman.sphere360.data.FillMode
import com.ayman.sphere360.data.LensMode
import com.ayman.sphere360.data.Session
import com.ayman.sphere360.data.SessionRepository
import com.ayman.sphere360.geometry.SphereMath
import com.ayman.sphere360.player.ColorMatch
import com.ayman.sphere360.player.DualPlayer
import com.ayman.sphere360.player.PhotoSphereExporter
import com.ayman.sphere360.player.SphereRenderer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun PlayerScreen(sessionDir: String, onBack: () -> Unit) {
    val session = remember(sessionDir) { SessionRepository.load(File(sessionDir)) }
    if (session == null) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            TopBar("Player", onBack)
            Text("This recording can't be opened.", modifier = Modifier.padding(20.dp))
        }
        return
    }
    PlayerContent(session, onBack)
}

private fun buildParams(s: Session, c: Calibration): SphereRenderer.Params {
    val oursToAndroid = SphereRenderer.OURS_TO_ANDROID
    val viewToWorld = FloatArray(16)
    val worldToDev = FloatArray(16)
    val r = s.orientation
    if (r != null && c.useOrientation) {
        // Turn the view so "forward" is where the rear camera pointed, with the horizon level.
        val ax = -r[2]
        val ay = -r[6]
        val heading = Math.toDegrees(kotlin.math.atan2(-ax.toDouble(), ay.toDouble())).toFloat()
        val ry = FloatArray(16)
        android.opengl.Matrix.setRotateM(ry, 0, heading, 0f, 1f, 0f)
        android.opengl.Matrix.multiplyMM(viewToWorld, 0, oursToAndroid, 0, ry, 0)
        System.arraycopy(r, 0, worldToDev, 0, 16)
    } else {
        System.arraycopy(oursToAndroid, 0, viewToWorld, 0, 16)
        android.opengl.Matrix.transposeM(worldToDev, 0, oursToAndroid, 0)
    }
    val fill = when (c.fill) {
        FillMode.GRID -> 0
        FillMode.SOFT -> 1
        FillMode.BACKGROUND -> if (s.hasBackground) 2 else 1
    }
    val rear = SphereMath.lensFor(
        s.rear.hFovDeg, s.rear.width, s.rear.height,
        ((s.rear.sensorOrientation + c.rearQuarter * 90) % 360).toFloat(), c.circleScale
    )
    val front = SphereMath.lensFor(
        s.front.hFovDeg, s.front.width, s.front.height,
        ((s.front.sensorOrientation + c.frontQuarter * 90) % 360).toFloat(), c.circleScale
    )
    // How far each camera really reaches along the horizon, measured with the same math as the shader.
    var sRear = 1f
    var sFront = 1f
    if (c.mode == LensMode.NORMAL && c.stretch > 0f) {
        val v2d = FloatArray(16)
        android.opengl.Matrix.multiplyMM(v2d, 0, worldToDev, 0, viewToWorld, 0)
        val m = if (c.mirrorFront) -1.0 else 1.0
        fun reach(start: Double, step: Double, isRear: Boolean): Double {
            var deg = 0.0
            while (deg < 179.0) {
                val lon = Math.toRadians(start + step * (deg + 0.5))
                val vx = kotlin.math.sin(lon)
                val vz = -kotlin.math.cos(lon)
                val dx = v2d[0] * vx + v2d[8] * vz
                val dy = v2d[1] * vx + v2d[9] * vz
                val dz = v2d[2] * vx + v2d[10] * vz
                val hit = if (isRear) SphereMath.covered(dx, dy, -dz, rear, false, 0.0)
                else SphereMath.covered(-dx * m, dy, dz, front, false, 0.0)
                if (!hit) break
                deg += 0.5
            }
            return deg
        }
        val hr = (reach(0.0, 1.0, true) + reach(0.0, -1.0, true)) / 2
        val hf = (reach(180.0, 1.0, false) + reach(180.0, -1.0, false)) / 2
        if (hr > 5) sRear = 1f + ((90.0 / hr).toFloat().coerceIn(1f, 4f) - 1f) * c.stretch
        if (hf > 5) sFront = 1f + ((90.0 / hf).toFloat().coerceIn(1f, 4f) - 1f) * c.stretch
    }
    return SphereRenderer.Params(
        rear = rear,
        front = front,
        stretchRear = sRear,
        stretchFront = sFront,
        fisheye = c.mode == LensMode.FISHEYE,
        halfFovRad = Math.toRadians(c.fisheyeFovDeg / 2.0).toFloat(),
        blendRad = Math.toRadians(c.blendDeg.toDouble()).toFloat(),
        mirrorFront = c.mirrorFront,
        fill = fill,
        edge = when (fill) { 0 -> 0f; 2 -> c.edgeWidth; else -> 0.04f },
        bgYawRad = Math.toRadians(c.bgYawDeg.toDouble()).toFloat(),
        viewToWorld = viewToWorld,
        worldToDev = worldToDev
    )
}

@Composable
private fun PlayerContent(session: Session, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var cal by remember { mutableStateOf(session.calibration) }
    var glError by remember { mutableStateOf<String?>(null) }
    val player = remember { DualPlayer(session) }
    val mainHandler = remember { Handler(Looper.getMainLooper()) }
    val renderer = remember {
        SphereRenderer(
            backgroundFile = if (session.hasBackground) session.backgroundFile else null,
            onSurfaces = { a, b -> mainHandler.post { player.attach(a, b) } },
            onError = { msg -> mainHandler.post { glError = msg } }
        )
    }
    var glView by remember { mutableStateOf<GLSurfaceView?>(null) }
    val playing by player.playing.collectAsState()
    val position by player.positionMs.collectAsState()
    val duration by player.durationMs.collectAsState()
    val playerError by player.error.collectAsState()
    var coverage by remember { mutableStateOf<Float?>(null) }
    var showControls by remember { mutableStateOf(true) }
    var showTune by remember { mutableStateOf(false) }
    var gyro by remember { mutableStateOf(false) }
    var seeking by remember { mutableStateOf<Float?>(null) }
    var saving by remember { mutableStateOf(false) }

    var gains by remember { mutableStateOf<ColorMatch.Gains?>(null) }

    // Measure colour differences once per alignment change (not on every slider tick of other settings).
    LaunchedEffect(cal.bgYawDeg, cal.useOrientation, cal.rearQuarter, cal.frontQuarter, cal.mirrorFront, cal.mode) {
        if (!session.hasBackground) return@LaunchedEffect
        kotlinx.coroutines.delay(250)
        val base = buildParams(session, cal.copy(stretch = 0f))
        gains = withContext(Dispatchers.IO) {
            runCatching { ColorMatch.compute(session, base, base.bgYawRad, cal.mirrorFront) }.getOrNull()
        }
    }

    LaunchedEffect(cal, gains) {
        var p = buildParams(session, cal)
        val g = gains
        if (g != null && cal.colorMatch) p = p.copy(bgGainRear = g.rear, bgGainFront = g.front)
        renderer.params = p
        coverage = withContext(Dispatchers.Default) {
            SphereMath.coverage(p.rear, p.front, p.fisheye, p.halfFovRad.toDouble(), p.mirrorFront)
        }
    }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner, glView) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_PAUSE -> { glView?.onPause(); player.pause() }
                Lifecycle.Event.ON_RESUME -> glView?.onResume()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    DisposableEffect(Unit) {
        onDispose {
            player.release()
            runCatching { SessionRepository.save(session.copy(calibration = cal)) }
        }
    }

    DisposableEffect(gyro) {
        renderer.gyro = gyro
        if (!gyro) return@DisposableEffect onDispose { }
        val sm = context.getSystemService(SensorManager::class.java)
        val sensor = sm.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR) ?: sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        if (sensor == null) {
            Toast.makeText(context, "This phone has no motion sensor for look-around.", Toast.LENGTH_SHORT).show()
            gyro = false
            return@DisposableEffect onDispose { }
        }
        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) = renderer.setRotationVector(event.values)
            override fun onAccuracyChanged(s: Sensor?, accuracy: Int) {}
        }
        sm.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_GAME)
        renderer.requestRecenter()
        onDispose { sm.unregisterListener(listener) }
    }

    fun saveSphere() {
        saving = true
        renderer.requestEquirect(4096) { bmp ->
            scope.launch {
                val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                val uri = withContext(Dispatchers.IO) {
                    bmp?.let { b -> PhotoSphereExporter.save(context, b, "Sphere360_$stamp").also { b.recycle() } }
                }
                saving = false
                val msg = if (uri != null) "360 photo saved to Pictures/Sphere360" else "Couldn't save the 360 photo"
                Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
            }
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { c ->
                GLSurfaceView(c).apply {
                    setEGLContextClientVersion(2)
                    preserveEGLContextOnPause = true
                    setRenderer(renderer)
                    renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
                }.also { glView = it }
            },
            modifier = Modifier.fillMaxSize(),
            onRelease = { v ->
                v.queueEvent { renderer.releaseGl() }
                v.onPause()
            }
        )

        // Touch layer: drag to look, pinch to zoom, tap to show or hide controls.
        Box(
            Modifier
                .fillMaxSize()
                .pointerInput(Unit) { detectTapGestures(onTap = { showControls = !showControls }) }
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        val k = renderer.fovDeg / size.height.coerceAtLeast(1).toFloat()
                        renderer.yawDeg -= pan.x * k
                        if (!renderer.gyro) renderer.pitchDeg = (renderer.pitchDeg - pan.y * k).coerceIn(-89f, 89f)
                        if (zoom != 1f) renderer.fovDeg = (renderer.fovDeg / zoom).coerceIn(35f, 115f)
                    }
                }
        )

        val err = glError ?: playerError
        if (err != null) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.error.copy(alpha = 0.9f),
                modifier = Modifier.align(Alignment.Center).padding(24.dp)
            ) {
                Text(err, color = Color.Black, modifier = Modifier.padding(16.dp))
            }
        }

        AnimatedVisibility(
            visible = showControls,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.TopCenter)
        ) {
            Column(
                Modifier.fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.75f), Color.Transparent)))
                    .statusBarsPadding()
                    .padding(bottom = 18.dp)
            ) {
                TopBar(formatDate(session.createdAt), onBack)
                Row(
                    Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Pill(if (cal.mode == LensMode.FISHEYE) "Dual fisheye" else "No lens")
                    coverage?.let { c ->
                        val full = c >= 0.995f
                        Pill(
                            if (full) "Video covers the full sphere" else "Video covers ${(c * 100).roundToInt()}%",
                            if (full) MaterialTheme.colorScheme.secondary.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant,
                            if (full) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurface
                        )
                    }
                    val fillLabel = when {
                        coverage?.let { it >= 0.995f } == true -> null
                        cal.fill == FillMode.BACKGROUND && session.hasBackground -> "Rest: room photo"
                        cal.fill == FillMode.GRID -> null
                        else -> "Rest: soft fill"
                    }
                    fillLabel?.let { Pill(it) }
                    if (cal.mode == LensMode.NORMAL && cal.stretch > 0.01f) Pill("Sides stretched")
                    if (cal.fill == FillMode.BACKGROUND && cal.colorMatch && gains != null) Pill("Colors matched")
                }
            }
        }

        AnimatedVisibility(
            visible = showControls,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            Column(
                Modifier.fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.85f))))
                    .navigationBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                AnimatedVisibility(visible = showTune) {
                    TunePanel(cal, session.hasBackground, session.orientation != null, onChange = { cal = it })
                }
                val dur = duration.coerceAtLeast(1L)
                Slider(
                    value = (seeking ?: (position.toFloat() / dur)).coerceIn(0f, 1f),
                    onValueChange = { seeking = it },
                    onValueChangeFinished = {
                        seeking?.let { player.seekTo((it * dur).toLong()) }
                        seeking = null
                    }
                )
                Row(Modifier.fillMaxWidth()) {
                    val shown = seeking?.let { (it * dur).toLong() } ?: position
                    Text(formatDuration(shown), style = MaterialTheme.typography.labelMedium, color = Color.White)
                    Spacer(Modifier.weight(1f))
                    Text(formatDuration(duration), style = MaterialTheme.typography.labelMedium, color = Color.White)
                }
                Row(
                    Modifier.fillMaxWidth().padding(top = 6.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ControlButton(Icons.Filled.ScreenRotation, "Move phone", selected = gyro) { gyro = !gyro }
                    ControlButton(Icons.Filled.CenterFocusStrong, "Recenter") { renderer.requestRecenter() }
                    FilledIconButton(onClick = { player.toggle() }, modifier = Modifier.size(64.dp)) {
                        Icon(
                            if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                            contentDescription = if (playing) "Pause" else "Play",
                            modifier = Modifier.size(32.dp)
                        )
                    }
                    ControlButton(Icons.Filled.Tune, "Adjust", selected = showTune) { showTune = !showTune }
                    ControlButton(Icons.Filled.Panorama, if (saving) "Saving" else "360 photo", enabled = !saving) { saveSphere() }
                }
            }
        }
    }
}

@Composable
private fun ControlButton(
    icon: ImageVector,
    label: String,
    selected: Boolean = false,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        IconButton(onClick = onClick, enabled = enabled) {
            Icon(icon, contentDescription = label, tint = if (selected) MaterialTheme.colorScheme.primary else Color.White)
        }
        Text(label, style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.85f))
    }
}

@Composable
private fun TunePanel(cal: Calibration, hasBackground: Boolean, hasOrientation: Boolean, onChange: (Calibration) -> Unit) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f),
        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Adjust the sphere", style = MaterialTheme.typography.titleSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = cal.mode == LensMode.NORMAL,
                    onClick = { onChange(cal.copy(mode = LensMode.NORMAL)) },
                    label = { Text("No lens") }
                )
                FilterChip(
                    selected = cal.mode == LensMode.FISHEYE,
                    onClick = { onChange(cal.copy(mode = LensMode.FISHEYE)) },
                    label = { Text("Fisheye lens") }
                )
            }
            if (cal.mode == LensMode.NORMAL) {
                LabeledSlider("Bring views together", "${(cal.stretch * 100).roundToInt()}%", cal.stretch, 0f..1f) {
                    onChange(cal.copy(stretch = it))
                }
            }
            Text("Areas the cameras didn't see", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (hasBackground) {
                    FilterChip(
                        selected = cal.fill == FillMode.BACKGROUND,
                        onClick = { onChange(cal.copy(fill = FillMode.BACKGROUND, stretch = 0f)) },
                        label = { Text("Room photo") }
                    )
                }
                FilterChip(
                    selected = cal.fill == FillMode.SOFT || (cal.fill == FillMode.BACKGROUND && !hasBackground),
                    onClick = { onChange(cal.copy(fill = FillMode.SOFT)) },
                    label = { Text("Soft fill") }
                )
                FilterChip(
                    selected = cal.fill == FillMode.GRID,
                    onClick = { onChange(cal.copy(fill = FillMode.GRID)) },
                    label = { Text("Grid") }
                )
            }
            if (hasBackground && cal.fill == FillMode.BACKGROUND) {
                LabeledSlider("Blend width", "${(cal.edgeWidth * 100).roundToInt()}%", cal.edgeWidth, 0.02f..0.35f) {
                    onChange(cal.copy(edgeWidth = it))
                }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Match colors to the video", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                    androidx.compose.material3.Switch(checked = cal.colorMatch, onCheckedChange = { onChange(cal.copy(colorMatch = it)) })
                }
                LabeledSlider("Turn room photo", "${cal.bgYawDeg.roundToInt()} degrees", cal.bgYawDeg, -180f..180f) {
                    onChange(cal.copy(bgYawDeg = it))
                }
            }
            if (hasOrientation) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Keep horizon level", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                    androidx.compose.material3.Switch(checked = cal.useOrientation, onCheckedChange = { onChange(cal.copy(useOrientation = it)) })
                }
            }
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(onClick = { onChange(cal.copy(rearQuarter = (cal.rearQuarter + 1) % 4)) }) {
                    Icon(Icons.Filled.Rotate90DegreesCw, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Turn rear")
                }
                OutlinedButton(onClick = { onChange(cal.copy(frontQuarter = (cal.frontQuarter + 1) % 4)) }) {
                    Icon(Icons.Filled.Rotate90DegreesCw, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Turn front")
                }
                FilterChip(
                    selected = cal.mirrorFront,
                    onClick = { onChange(cal.copy(mirrorFront = !cal.mirrorFront)) },
                    label = { Text("Mirror front") }
                )
            }
            if (cal.mode == LensMode.FISHEYE) {
                LabeledSlider("Lens angle", "${cal.fisheyeFovDeg.roundToInt()} degrees", cal.fisheyeFovDeg, 150f..240f) {
                    onChange(cal.copy(fisheyeFovDeg = it))
                }
                LabeledSlider("Lens circle size", String.format(Locale.US, "%.2f", cal.circleScale), cal.circleScale, 0.6f..1.6f) {
                    onChange(cal.copy(circleScale = it))
                }
                LabeledSlider("Seam softness", "${cal.blendDeg.roundToInt()} degrees", cal.blendDeg, 1f..20f) {
                    onChange(cal.copy(blendDeg = it))
                }
            }
            Text(
                "If a view looks sideways, tap Turn rear or Turn front until it's upright.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun LabeledSlider(
    label: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit
) {
    Column {
        Row(Modifier.fillMaxWidth()) {
            Text(label, style = MaterialTheme.typography.labelLarge, modifier = Modifier.weight(1f))
            Text(valueText, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Slider(value = value, onValueChange = onChange, valueRange = range)
    }
}
