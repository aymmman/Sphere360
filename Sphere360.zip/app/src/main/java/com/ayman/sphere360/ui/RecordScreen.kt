package com.ayman.sphere360.ui

import android.app.Activity
import android.graphics.SurfaceTexture
import android.util.Size
import android.view.TextureView
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.currentStateAsState
import com.ayman.sphere360.camera.DualRecorder
import com.ayman.sphere360.camera.RecordConfig
import com.ayman.sphere360.data.LensMode
import com.ayman.sphere360.data.Session
import kotlinx.coroutines.launch
import java.util.Locale

@Composable
fun RecordScreen(onBack: () -> Unit, onOpenSession: (String) -> Unit) {
    val context = LocalContext.current
    val activity = context as? Activity
    val scope = rememberCoroutineScope()
    val recorder = remember { DualRecorder(context.applicationContext) }
    val status by recorder.status.collectAsState()
    var config by remember { mutableStateOf(RecordConfig()) }
    var rearTex by remember { mutableStateOf<SurfaceTexture?>(null) }
    var frontTex by remember { mutableStateOf<SurfaceTexture?>(null) }
    var showSettings by remember { mutableStateOf(false) }
    var lastSaved by remember { mutableStateOf<Session?>(null) }
    var retry by remember { mutableIntStateOf(0) }

    val lifecycleState by LocalLifecycleOwner.current.lifecycle.currentStateAsState()
    val active = lifecycleState.isAtLeast(Lifecycle.State.STARTED)
    val recording = status.state == DualRecorder.State.RECORDING

    // Open the cameras when both previews exist and the app is visible; close (and save) otherwise.
    LaunchedEffect(rearTex, frontTex, active, config, retry) {
        val r = rearTex
        val f = frontTex
        if (active && r != null && f != null) {
            recorder.open(r, f, config)
        } else {
            recorder.shutdown()?.let { lastSaved = it }
        }
    }

    DisposableEffect(Unit) {
        activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose {
            activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            recorder.release()
        }
    }

    fun stopAndLeave() {
        scope.launch {
            recorder.stopRecording()
            onBack()
        }
    }
    BackHandler(enabled = recording) { stopAndLeave() }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            TopBar(title = "Record", onBack = { if (recording) stopAndLeave() else onBack() }) {
                IconButton(onClick = { showSettings = !showSettings }, enabled = !recording) {
                    Icon(Icons.Filled.Settings, contentDescription = "Recording settings")
                }
            }
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                PreviewTile("Rear", Modifier.weight(1f)) { rearTex = it }
                PreviewTile("Front", Modifier.weight(1f)) { frontTex = it }
            }
            Spacer(Modifier.height(12.dp))
            StatusRow(status, config)
            status.message?.let { msg ->
                MessageCard(msg, isError = status.state == DualRecorder.State.ERROR, onRetry = { retry++ })
            }
            Spacer(Modifier.weight(1f))
            Column(
                Modifier.fillMaxWidth().padding(bottom = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                TimerText(status.elapsedMs, recording)
                Spacer(Modifier.height(14.dp))
                RecordButton(
                    recording = recording,
                    enabled = status.state == DualRecorder.State.READY || recording
                ) {
                    scope.launch {
                        if (recording) {
                            lastSaved = recorder.stopRecording()
                        } else {
                            recorder.startRecording()
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                val saved = lastSaved
                if (saved != null && !recording) {
                    TextButton(onClick = { onOpenSession(saved.dir.absolutePath) }) {
                        Text("Watch the last recording in 360")
                    }
                } else {
                    Spacer(Modifier.height(48.dp))
                }
            }
        }

        AnimatedVisibility(
            visible = showSettings && !recording,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically { it },
            exit = slideOutVertically { it }
        ) {
            SettingsSheet(config, onChange = { config = it }, onClose = { showSettings = false })
        }
    }
}

@Composable
private fun PreviewTile(label: String, modifier: Modifier, onTexture: (SurfaceTexture?) -> Unit) {
    Box(
        modifier.aspectRatio(9f / 16f).clip(RoundedCornerShape(18.dp)).background(Color(0xFF0B1019))
    ) {
        AndroidView(
            factory = { c ->
                TextureView(c).apply {
                    surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                        override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) = onTexture(st)
                        override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}
                        override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
                            onTexture(null)
                            return true
                        }
                        override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
                    }
                }
            },
            modifier = Modifier.fillMaxSize()
        )
        Box(Modifier.align(Alignment.TopStart).padding(8.dp)) {
            Pill(label, Color.Black.copy(alpha = 0.55f), Color.White)
        }
    }
}

@Composable
private fun StatusRow(status: DualRecorder.Status, config: RecordConfig) {
    val size = status.recordSize ?: Size(if (config.resolution >= 1080) 1920 else 1280, config.resolution)
    val perMin = DualRecorder.bytesPerMinute(size, config.audio)
    val minutesLeft = if (perMin > 0) status.freeBytes / perMin else 0
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Pill(if (config.lensMode == LensMode.FISHEYE) "Fisheye lens mode" else "No lens mode")
        Pill("${size.height}p, 30 fps")
        if (status.state == DualRecorder.State.RECORDING) {
            Pill(String.format(Locale.US, "Rear %.1f fps", status.fpsRear))
            Pill(String.format(Locale.US, "Front %.1f fps", status.fpsFront))
            val dropped = status.droppedRear + status.droppedFront
            Pill(
                "Dropped frames $dropped",
                if (dropped > 0) MaterialTheme.colorScheme.error.copy(alpha = 0.18f) else MaterialTheme.colorScheme.surfaceVariant,
                if (dropped > 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
            )
        }
        Pill("Phone: ${thermalLabel(status.thermal)}")
        Pill("Space for about $minutesLeft min")
    }
}

@Composable
private fun MessageCard(message: String, isError: Boolean, onRetry: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = if (isError) MaterialTheme.colorScheme.error.copy(alpha = 0.14f) else MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier.fillMaxWidth().padding(12.dp)
    ) {
        Row(Modifier.padding(start = 14.dp, end = 4.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(message, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
            if (isError) TextButton(onClick = onRetry) { Text("Try again") }
        }
    }
}

@Composable
private fun TimerText(elapsedMs: Long, recording: Boolean) {
    val pulse = rememberInfiniteTransition(label = "pulse")
    val a by pulse.animateFloat(
        initialValue = 1f, targetValue = 0.25f,
        animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "dot"
    )
    Row(verticalAlignment = Alignment.CenterVertically) {
        if (recording) {
            Box(Modifier.size(10.dp).alpha(a).clip(CircleShape).background(RecordRed))
            Spacer(Modifier.width(8.dp))
        }
        Text(formatDuration(elapsedMs), fontSize = 30.sp, fontWeight = FontWeight.Medium, color = Color.White)
    }
}

@Composable
private fun RecordButton(recording: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val inner by animateDpAsState(if (recording) 30.dp else 64.dp, label = "inner")
    val corner by animateDpAsState(if (recording) 8.dp else 32.dp, label = "corner")
    Box(
        Modifier
            .size(84.dp)
            .clip(CircleShape)
            .border(4.dp, Color.White.copy(alpha = if (enabled) 1f else 0.3f), CircleShape)
            .clickable(enabled = enabled, onClick = onClick)
            .semantics { contentDescription = if (recording) "Stop recording" else "Start recording" },
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier.size(inner).clip(RoundedCornerShape(corner))
                .background(if (enabled) RecordRed else RecordRed.copy(alpha = 0.35f))
        )
    }
}

@Composable
private fun SettingsSheet(config: RecordConfig, onChange: (RecordConfig) -> Unit, onClose: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        tonalElevation = 6.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            Modifier.navigationBarsPadding().padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Recording settings", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                TextButton(onClick = onClose) { Text("Done") }
            }
            OptionRow("Lens", listOf("No lens" to LensMode.NORMAL, "Fisheye clip-on" to LensMode.FISHEYE), config.lensMode) {
                onChange(config.copy(lensMode = it))
            }
            OptionRow("Quality", listOf("1080p" to 1080, "720p" to 720), config.resolution) {
                onChange(config.copy(resolution = it))
            }
            OptionRow("Rear camera", listOf("Ultra-wide" to true, "Main" to false), config.ultraWide) {
                onChange(config.copy(ultraWide = it))
            }
            OptionRow("Stop after", listOf("5 min" to 5, "10 min" to 10, "30 min" to 30), config.maxMinutes) {
                onChange(config.copy(maxMinutes = it))
            }
            SwitchRow("Record sound", config.audio) { onChange(config.copy(audio = it)) }
            SwitchRow("Stabilization", config.stabilization) { onChange(config.copy(stabilization = it)) }
            Text(
                "With a fisheye clip-on, put it on the rear lens you picked above and keep stabilization off, " +
                    "because stabilization crops and bends the picture.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun <T> OptionRow(label: String, options: List<Pair<String, T>>, selected: T, onSelect: (T) -> Unit) {
    Column {
        Text(label, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEach { (text, value) ->
                FilterChip(selected = value == selected, onClick = { onSelect(value) }, label = { Text(text) })
            }
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
