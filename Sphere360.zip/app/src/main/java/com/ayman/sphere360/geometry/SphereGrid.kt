package com.ayman.sphere360.geometry

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Tracks which parts of the world sphere the scan has seen, from the phone orientation
 * and the camera's field of view. Area-weighted, so the poles don't count extra.
 */
class SphereGrid(private val cols: Int = 72, private val rows: Int = 36) {
    private val hit = BooleanArray(cols * rows)
    private val weight = DoubleArray(rows) { r -> cos(-PI / 2 + (r + 0.5) * PI / rows) }
    private val total = weight.sum() * cols

    fun reset() = hit.fill(false)

    /** worldToDev: 16-float column-major (OpenGL) matrix, Android world frame (Z up). */
    fun mark(worldToDev: FloatArray, lens: SphereMath.Lens) {
        // Count only the inner 85% of the frame, where the paint is fully opaque.
        val inner = lens.copy(tanW = lens.tanW * 0.85f, tanH = lens.tanH * 0.85f)
        for (r in 0 until rows) {
            val lat = -PI / 2 + (r + 0.5) * PI / rows
            for (c in 0 until cols) {
                val idx = r * cols + c
                if (hit[idx]) continue
                val lon = -PI + (c + 0.5) * 2 * PI / cols
                val wx = cos(lat) * sin(lon)
                val wy = cos(lat) * cos(lon)
                val wz = sin(lat)
                val dx = worldToDev[0] * wx + worldToDev[4] * wy + worldToDev[8] * wz
                val dy = worldToDev[1] * wx + worldToDev[5] * wy + worldToDev[9] * wz
                val dz = worldToDev[2] * wx + worldToDev[6] * wy + worldToDev[10] * wz
                // Rear camera looks along device -Z.
                if (SphereMath.covered(dx, dy, -dz, inner, false, 0.0)) hit[idx] = true
            }
        }
    }

    fun fraction(): Float {
        var sum = 0.0
        for (r in 0 until rows) for (c in 0 until cols) if (hit[r * cols + c]) sum += weight[r]
        return (sum / total).toFloat()
    }
}
