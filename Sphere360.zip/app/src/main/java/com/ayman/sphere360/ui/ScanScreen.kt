package com.ayman.sphere360.ui

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Rect
import android.graphics.SurfaceTexture
import android.opengl.GLSurfaceView
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.currentStateAsState
import com.ayman.sphere360.camera.OrientationTracker
import com.ayman.sphere360.camera.ScanCamera
import com.ayman.sphere360.data.BackgroundStore
import com.ayman.sphere360.geometry.SphereGrid
import com.ayman.sphere360.geometry.SphereMath
import com.ayman.sphere360.player.PhotoSphereExporter
import com.ayman.sphere360.player.ScanRenderer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt
import kotlin.math.tan

@Composable
fun ScanScreen(onDone: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val main = remember { Handler(Looper.getMainLooper()) }
    val prefs = remember { context.getSharedPreferences("scan", 0) }
    var camTex by remember { mutableStateOf<SurfaceTexture?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val renderer = remember {
        ScanRenderer(
            onCameraTexture = { st -> main.post { camTex = st } },
            onError = { msg -> main.post { error = msg } }
        )
    }
    val camera = remember { ScanCamera(context.applicationContext) }
    val tracker = remember { OrientationTracker(context.applicationContext) }
    val grid = remember { SphereGrid() }
    var info by remember { mutableStateOf<ScanCamera.Info?>(null) }
    var turnMode by remember { mutableIntStateOf(prefs.getInt("turnMode", 0)) }
    var painting by remember { mutableStateOf(false) }
    var coverage by remember { mutableFloatStateOf(0f) }
    var saving by remember { mutableStateOf(false) }
    var alsoToPhotos by remember { mutableStateOf(true) }
    var glView by remember { mutableStateOf<GLSurfaceView?>(null) }

    val lifecycleState by LocalLifecycleOwner.current.lifecycle.currentStateAsState()
    val active = lifecycleState.isAtLeast(Lifecycle.State.STARTED)

    DisposableEffect(Unit) {
        tracker.listener = { m -> renderer.worldToDev = m }
        tracker.start()
        if (!tracker.available) error = "This phone has no orientation sensor, so a room scan isn't possible."
        onDispose {
            tracker.stop()
            tracker.listener = null
            camera.release()
        }
    }

    LaunchedEffect(camTex, active) {
        val st = camTex
        if (st != null && active) {
            try {
                info = withContext(Dispatchers.IO) { camera.open(st) }
                glView?.onResume()
            } catch (e: Exception) {
                error = e.message ?: "The camera couldn't start."
            }
        } else {
            camera.close()
            painting = false
        }
    }

    // Lens for painting. Mode 0: the camera already turns the picture upright. Mode 1: raw sensor frame.
    val lens = remember(info, turnMode) {
        info?.let { i ->
            val tanLong = tan(Math.toRadians(i.hFovDeg / 2.0)).toFloat()
            val ratio = i.height.toFloat() / i.width
            if (turnMode == 0) SphereMath.Lens(0f, tanLong * ratio, tanLong, 0f, 0f)
            else SphereMath.Lens(i.sensorOrientation.toFloat(), tanLong, tanLong * ratio, 0f, 0f)
        }
    }
    LaunchedEffect(lens) {
        renderer.lens = lens
        renderer.previewAspect = info?.let { if (turnMode == 0) it.height.toFloat() / it.width else it.width.toFloat() / it.height } ?: (9f / 16f)
    }
    LaunchedEffect(painting) { renderer.painting = painting }

    LaunchedEffect(painting, lens) {
        val l = lens ?: return@LaunchedEffect
        while (painting) {
            tracker.matrix()?.let { m ->
                coverage = withContext(Dispatchers.Default) { grid.mark(m, l); grid.fraction() }
            }
            delay(150)
        }
    }

    fun save() {
        saving = true
        painting = false
        val cov = coverage
        renderer.requestCanvas { bmp ->
            scope.launch {
                val ok = withContext(Dispatchers.IO) {
                    if (bmp == null) return@withContext false
                    runCatching {
                        BackgroundStore.save(context, bmp, cov)
                        if (alsoToPhotos) {
                            val out = Bitmap.createBitmap(bmp.width, bmp.height, Bitmap.Config.ARGB_8888)
                            Canvas(out).apply {
                                drawColor(0xFF141B29.toInt())
                                drawBitmap(bmp, 0f, 0f, null)
                            }
                            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                            PhotoSphereExporter.save(context, out, "Sphere360_room_$stamp")
                            out.recycle()
                        }
                        bmp.recycle()
                        true
                    }.getOrDefault(false)
                }
                saving = false
                Toast.makeText(
                    context,
                    if (ok) "Room scan saved. New recordings will use it." else "Couldn't save the room scan.",
                    Toast.LENGTH_LONG
                ).show()
                if (ok) onDone()
            }
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { c ->
                GLSurfaceView(c).apply {
                    setEGLContextClientVersion(2)
                    preserveEGLContextOnPause = true
                    setRenderer(renderer)
                    renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
                }.also { glView = it }
            },
            modifier = Modifier.fillMaxSize(),
            onRelease = { v ->
                v.queueEvent { renderer.releaseGl() }
                v.onPause()
            }
        )

        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            TopBar("Scan the room", onDone)
            // The panorama is drawn by OpenGL exactly where this box sits.
            Box(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp)
                    .aspectRatio(2f)
                    .clip(RoundedCornerShape(12.dp))
                    .onGloballyPositioned { coords ->
                        val p = coords.positionInWindow()
                        val w = coords.size.width
                        val h = coords.size.height
                        renderer.panoRect = Rect(p.x.roundToInt(), p.y.roundToInt(), p.x.roundToInt() + w, p.y.roundToInt() + h)
                    }
            )
            Spacer(Modifier.height(10.dp))
            Column(Modifier.padding(horizontal = 16.dp)) {
                LinearProgressIndicator(
                    progress = { coverage.coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp))
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    "Room captured: ${(coverage * 100).roundToInt()}%",
                    style = MaterialTheme.typography.labelLarge,
                    color = Color.White
                )
            }
            Spacer(Modifier.weight(1f))
            Surface(
                shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium) }
                    Text(
                        if (painting) "Turn slowly in place, then tilt up to the ceiling and down to the floor. Keep the phone at the same spot."
                        else "Stand where you'll record. Tap Start, then turn slowly all the way around.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Button(onClick = { painting = !painting }, enabled = lens != null && !saving && tracker.available) {
                            Text(if (painting) "Pause" else if (coverage > 0f) "Continue" else "Start")
                        }
                        OutlinedButton(onClick = {
                            renderer.reset()
                            grid.reset()
                            coverage = 0f
                        }, enabled = !saving) { Text("Start over") }
                        TextButton(onClick = {
                            turnMode = 1 - turnMode
                            prefs.edit().putInt("turnMode", turnMode).apply()
                            renderer.reset(); grid.reset(); coverage = 0f
                        }) { Text("Picture sideways?") }
                    }
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("Also save to Photos as a 360 photo", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                        Switch(checked = alsoToPhotos, onCheckedChange = { alsoToPhotos = it })
                    }
                    Button(
                        onClick = { save() },
                        enabled = coverage > 0.05f && !saving,
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(if (saving) "Saving" else "Save room scan") }
                }
            }
        }
    }
}
