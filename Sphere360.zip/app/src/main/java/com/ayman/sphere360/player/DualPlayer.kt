package com.ayman.sphere360.player

import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.view.Surface
import com.ayman.sphere360.data.Session
import kotlinx.coroutines.flow.MutableStateFlow
import kotlin.math.abs

/**
 * Plays rear.mp4 (with sound) as the master clock and keeps front.mp4 in step,
 * using the start offset measured from the camera sensor clocks.
 */
class DualPlayer(private val session: Session) {

    val playing = MutableStateFlow(false)
    val positionMs = MutableStateFlow(0L)
    val durationMs = MutableStateFlow(0L)
    val error = MutableStateFlow<String?>(null)

    private val main = Handler(Looper.getMainLooper())
    private val rearExists = session.rearFile.exists()
    private val frontExists = session.frontFile.exists()
    private val master: MediaPlayer? = if (rearExists || frontExists) MediaPlayer() else null
    private val slave: MediaPlayer? = if (rearExists && frontExists) MediaPlayer() else null
    private val masterIsRear = rearExists
    private val offsetMs = if (rearExists && frontExists) session.frontOffsetMs else 0L

    private var attached = false
    private var prepared = 0
    private var ready = false
    private var released = false
    private var slaveDuration = 0L

    private val ticker = object : Runnable {
        override fun run() {
            if (released) return
            runCatching { sync() }
            main.postDelayed(this, 200)
        }
    }

    /** Called on the main thread every time the renderer (re)creates its surfaces. */
    fun attach(rearSurface: Surface, frontSurface: Surface) {
        if (released) return
        val m = master
        if (m == null) {
            error.value = "No video files were found for this recording."
            return
        }
        runCatching {
            m.setSurface(if (masterIsRear) rearSurface else frontSurface)
            slave?.setSurface(frontSurface)
        }
        if (attached) return
        attached = true
        try {
            m.setDataSource((if (masterIsRear) session.rearFile else session.frontFile).absolutePath)
            m.setOnPreparedListener { onPrepared() }
            m.setOnCompletionListener {
                playing.value = false
                slave?.let { s -> if (runCatching { s.isPlaying }.getOrDefault(false)) s.pause() }
            }
            m.setOnErrorListener { _, what, extra -> error.value = "Video playback error ($what, $extra)"; true }
            m.prepareAsync()
            slave?.let { s ->
                s.setDataSource(session.frontFile.absolutePath)
                s.setVolume(0f, 0f)
                s.setOnPreparedListener { onPrepared() }
                s.setOnErrorListener { _, what, extra -> error.value = "Front video error ($what, $extra)"; true }
                s.prepareAsync()
            }
        } catch (e: Exception) {
            error.value = "Couldn't open the video: ${e.message}"
        }
        main.post(ticker)
    }

    private fun onPrepared() {
        prepared++
        val needed = if (slave != null) 2 else 1
        if (prepared < needed || released) return
        val m = master ?: return
        ready = true
        durationMs.value = m.duration.toLong()
        slaveDuration = slave?.duration?.toLong() ?: 0L
        seekTo(0)
        play()
    }

    fun play() {
        if (!ready || released) return
        val m = master ?: return
        if (m.currentPosition >= m.duration - 150) seekTo(0)
        m.start()
        playing.value = true
        runCatching { sync() }
    }

    fun pause() {
        if (!ready || released) return
        runCatching { master?.takeIf { it.isPlaying }?.pause() }
        runCatching { slave?.takeIf { it.isPlaying }?.pause() }
        playing.value = false
    }

    fun toggle() {
        if (playing.value) pause() else play()
    }

    fun seekTo(ms: Long) {
        if (!ready || released) return
        master?.seekTo(ms, MediaPlayer.SEEK_CLOSEST)
        slave?.let { s -> s.seekTo((ms - offsetMs).coerceIn(0L, slaveDuration), MediaPlayer.SEEK_CLOSEST) }
        positionMs.value = ms
    }

    private fun sync() {
        if (!ready || released) return
        val m = master ?: return
        val pos = m.currentPosition.toLong()
        positionMs.value = pos
        val s = slave ?: return
        val target = pos - offsetMs
        if (!playing.value || target < 0 || target > slaveDuration) {
            if (s.isPlaying) s.pause()
            return
        }
        if (!s.isPlaying) {
            s.seekTo(target, MediaPlayer.SEEK_CLOSEST)
            s.start()
            return
        }
        val drift = s.currentPosition - target
        if (abs(drift) > 120) s.seekTo(target + 30, MediaPlayer.SEEK_CLOSEST)
    }

    fun release() {
        released = true
        main.removeCallbacks(ticker)
        runCatching { master?.release() }
        runCatching { slave?.release() }
    }
}
