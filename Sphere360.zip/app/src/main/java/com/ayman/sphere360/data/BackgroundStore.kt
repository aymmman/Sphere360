package com.ayman.sphere360.data

import android.content.Context
import android.graphics.Bitmap
import org.json.JSONObject
import java.io.File

/** The latest room scan: a 2048x1024 equirectangular PNG (alpha = how well each spot was captured). */
object BackgroundStore {

    data class Background(val file: File, val createdAt: Long, val coverage: Float)

    private fun dir(context: Context) = File(context.filesDir, "backgrounds").apply { mkdirs() }

    fun latest(context: Context): Background? {
        val d = dir(context)
        val png = File(d, "latest.png")
        if (!png.exists()) return null
        val meta = runCatching { JSONObject(File(d, "latest.json").readText()) }.getOrNull()
        return Background(
            file = png,
            createdAt = meta?.optLong("createdAt", png.lastModified()) ?: png.lastModified(),
            coverage = meta?.optDouble("coverage", 0.0)?.toFloat() ?: 0f
        )
    }

    fun save(context: Context, bitmap: Bitmap, coverage: Float): Background {
        val d = dir(context)
        val tmp = File(d, "latest.png.tmp")
        tmp.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
        val png = File(d, "latest.png")
        tmp.renameTo(png)
        val now = System.currentTimeMillis()
        File(d, "latest.json").writeText(
            JSONObject().put("createdAt", now).put("coverage", coverage.toDouble()).toString()
        )
        return Background(png, now, coverage)
    }

    fun delete(context: Context) {
        val d = dir(context)
        File(d, "latest.png").delete()
        File(d, "latest.json").delete()
    }
}
