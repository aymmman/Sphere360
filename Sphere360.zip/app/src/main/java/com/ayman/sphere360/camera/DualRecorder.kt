package com.ayman.sphere360.camera

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureFailure
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.CaptureResult
import android.hardware.camera2.TotalCaptureResult
import android.hardware.camera2.params.OutputConfiguration
import android.hardware.camera2.params.SessionConfiguration
import android.media.MediaCodec
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.PowerManager
import android.os.SystemClock
import android.util.Log
import android.util.Range
import android.util.Size
import android.view.Surface
import androidx.core.content.ContextCompat
import com.ayman.sphere360.data.CamMeta
import com.ayman.sphere360.data.Calibration
import com.ayman.sphere360.data.FillMode
import com.ayman.sphere360.data.LensMode
import com.ayman.sphere360.data.Session
import com.ayman.sphere360.data.SessionRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File
import java.util.concurrent.Executor
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.max
import kotlin.math.roundToInt

data class RecordConfig(
    val resolution: Int = 1080,
    val lensMode: LensMode = LensMode.NORMAL,
    val ultraWide: Boolean = true,
    val audio: Boolean = true,
    val stabilization: Boolean = false,
    val maxMinutes: Int = 10,
    val useBackground: Boolean = true
)

/** Extra things captured at the moment recording starts. */
class RecordExtras(
    val orientation: FloatArray? = null,
    val background: File? = null,
    val bgCoverage: Float = 0f
)

/** Counts real frames from the camera, so fps and dropped frames are measured, not guessed. */
class FrameStats : CameraCaptureSession.CaptureCallback() {
    @Volatile var first = -1L
    @Volatile var last = -1L
    @Volatile var frames = 0
    @Volatile var dropped = 0

    fun reset() { first = -1L; last = -1L; frames = 0; dropped = 0 }

    override fun onCaptureCompleted(session: CameraCaptureSession, request: CaptureRequest, result: TotalCaptureResult) {
        val ts = result.get(CaptureResult.SENSOR_TIMESTAMP) ?: return
        if (first < 0) first = ts
        val prev = last
        if (prev > 0) {
            val gap = ts - prev
            if (gap > FRAME_NS * 3 / 2) dropped += max(1, (gap.toDouble() / FRAME_NS).roundToInt() - 1)
        }
        last = ts
        frames++
    }

    override fun onCaptureFailed(session: CameraCaptureSession, request: CaptureRequest, failure: CaptureFailure) {
        dropped++
    }

    fun fps(): Float = if (frames > 1 && last > first) (frames - 1) * 1e9f / (last - first) else 0f

    companion object { const val FRAME_NS = 33_333_333L }
}

/**
 * Records the front and rear cameras at the same time with Camera2 concurrent sessions.
 * Each camera writes its own MP4 through a persistent encoder surface.
 */
class NoConcurrentSupport : Exception("This phone doesn't let apps use the front and rear cameras at the same time.")

class DualRecorder(private val context: Context) {

    enum class State { IDLE, OPENING, READY, RECORDING, STOPPING, ERROR }

    data class Status(
        val state: State = State.IDLE,
        val message: String? = null,
        val elapsedMs: Long = 0,
        val recordSize: Size? = null,
        val fpsRear: Float = 0f,
        val fpsFront: Float = 0f,
        val droppedRear: Int = 0,
        val droppedFront: Int = 0,
        val thermal: Int = 0,
        val freeBytes: Long = 0,
        val rearZoom: Float = 1f
    )

    private val _status = MutableStateFlow(Status())
    val status: StateFlow<Status> = _status

    private val mgr = context.getSystemService(CameraManager::class.java)
    private val power = context.getSystemService(PowerManager::class.java)
    private val thread = HandlerThread("DualCamera").apply { start() }
    private val handler = Handler(thread.looper)
    private val executor = Executor { handler.post(it) }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    // Shared by every recorder instance, so a new screen waits until the old one has fully closed the cameras.
    private val mutex get() = CAMERA_LOCK

    private inner class Cam(val id: String, val chars: CameraCharacteristics) {
        var device: CameraDevice? = null
        var session: CameraCaptureSession? = null
        var preview: Surface? = null
        var encoderSurface: Surface? = null
        var recorder: MediaRecorder? = null
        var zoom = 1f
        var fpsRange: Range<Int>? = null
        val stats = FrameStats()
        val sensorOrientation: Int get() = chars.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 0
        val realtimeClock: Boolean get() = chars.get(CameraCharacteristics.SENSOR_INFO_TIMESTAMP_SOURCE) ==
            CameraMetadata.SENSOR_INFO_TIMESTAMP_SOURCE_REALTIME
    }

    private var rear: Cam? = null
    private var front: Cam? = null
    private var config = RecordConfig()
    private var recordSize: Size? = null
    private var sessionDir: File? = null
    private var startedAt = 0L
    private var createdAt = 0L
    private var withAudio = false
    private var tickJob: Job? = null
    private var extras = RecordExtras()
    private var bgCopied = false

    // ---------------------------------------------------------------- open / close

    suspend fun open(rearTex: SurfaceTexture, frontTex: SurfaceTexture, cfg: RecordConfig): Unit = mutex.withLock {
        closeInternal()
        config = cfg
        _status.value = Status(state = State.OPENING, freeBytes = freeBytes())
        var lastError: Exception? = null
        for (attempt in 1..MAX_OPEN_ATTEMPTS) {
            try {
                openOnce(rearTex, frontTex, cfg)
                return@withLock
            } catch (e: CancellationException) {
                closeInternal()
                throw e
            } catch (e: Exception) {
                Log.w(TAG, "open attempt $attempt failed", e)
                closeInternal()
                lastError = e
                // The camera service is often still releasing the previous session. Give it a moment.
                if (attempt < MAX_OPEN_ATTEMPTS && e !is NoConcurrentSupport) delay(700L * attempt) else break
            }
        }
        _status.value = Status(
            state = State.ERROR,
            message = lastError?.message ?: "The cameras couldn't start.",
            freeBytes = freeBytes()
        )
    }

    private suspend fun openOnce(rearTex: SurfaceTexture, frontTex: SurfaceTexture, cfg: RecordConfig) {
        run {
            val pair = CameraProbe.findFrontBackPair(mgr)
                ?: throw NoConcurrentSupport()
            val r = Cam(pair.first, mgr.getCameraCharacteristics(pair.first))
            val f = Cam(pair.second, mgr.getCameraCharacteristics(pair.second))
            rear = r
            front = f

            val previewSize = CameraProbe.choosePreviewSize(r.chars, f.chars)
            val size = chooseRecordSize(r, f, previewSize, cfg)
            recordSize = size
            r.zoom = if (cfg.ultraWide) CameraProbe.minZoom(r.chars) else 1f
            r.fpsRange = CameraProbe.fps30(r.chars)
            f.fpsRange = CameraProbe.fps30(f.chars)

            rearTex.setDefaultBufferSize(previewSize.width, previewSize.height)
            frontTex.setDefaultBufferSize(previewSize.width, previewSize.height)
            r.preview = Surface(rearTex)
            f.preview = Surface(frontTex)
            r.encoderSurface = makeEncoderSurface(size)
            f.encoderSurface = makeEncoderSurface(size)

            r.device = openDevice(r.id)
            f.device = openDevice(f.id)
            r.session = createSession(r.device!!, listOf(r.preview!!, r.encoderSurface!!))
            f.session = createSession(f.device!!, listOf(f.preview!!, f.encoderSurface!!))
            repeatRequest(r, recording = false)
            repeatRequest(f, recording = false)

            _status.value = _status.value.copy(state = State.READY, recordSize = size, rearZoom = r.zoom, thermal = power.currentThermalStatus)
        }
    }

    /** Stops any recording (saving it) and closes both cameras. */
    suspend fun shutdown(): Session? = mutex.withLock {
        val saved = if (_status.value.state == State.RECORDING) stopInternal() else null
        closeInternal()
        _status.value = Status(
            state = State.IDLE,
            freeBytes = freeBytes(),
            message = if (saved != null) "Recording stopped and saved." else null
        )
        saved
    }

    fun release() {
        scope.launch {
            runCatching { shutdown() }
            thread.quitSafely()
            scope.cancel()
        }
    }

    private fun closeInternal() {
        tickJob?.cancel()
        tickJob = null
        listOfNotNull(rear, front).forEach { c ->
            runCatching { c.session?.close() }
            runCatching { c.device?.close() }
            runCatching { c.recorder?.release() }
            runCatching { c.encoderSurface?.release() }
            runCatching { c.preview?.release() }
        }
        rear = null
        front = null
    }

    private fun chooseRecordSize(r: Cam, f: Cam, preview: Size, cfg: RecordConfig): Size {
        val wanted = if (cfg.resolution >= 1080) listOf(Size(1920, 1080), Size(1280, 720)) else listOf(Size(1280, 720))
        for (s in wanted) {
            if (!CameraProbe.supportsRecorderSize(r.chars, s) || !CameraProbe.supportsRecorderSize(f.chars, s)) continue
            if (CameraProbe.isConcurrentSupported(mgr, r.id, f.id, preview, s) != false) return s
        }
        throw CameraUnavailable("No video size works with both cameras running together on this phone.")
    }

    private fun newRecorder(): MediaRecorder =
        if (Build.VERSION.SDK_INT >= 31) MediaRecorder(context) else @Suppress("DEPRECATION") MediaRecorder()

    /** A surface the camera can keep writing into across several recordings. */
    private fun makeEncoderSurface(size: Size): Surface {
        val surface = MediaCodec.createPersistentInputSurface()
        val tmp = File(context.cacheDir, "init_${System.nanoTime()}.mp4")
        newRecorder().apply {
            setVideoSource(MediaRecorder.VideoSource.SURFACE)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setOutputFile(tmp.absolutePath)
            setVideoEncodingBitRate(4_000_000)
            setVideoFrameRate(30)
            setVideoSize(size.width, size.height)
            setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            setInputSurface(surface)
            prepare()
            release()
        }
        tmp.delete()
        return surface
    }

    @SuppressLint("MissingPermission")
    private suspend fun openDevice(id: String): CameraDevice = suspendCancellableCoroutine { cont ->
        mgr.openCamera(id, object : CameraDevice.StateCallback() {
            override fun onOpened(device: CameraDevice) {
                if (cont.isActive) cont.resume(device) else device.close()
            }

            override fun onDisconnected(device: CameraDevice) {
                device.close()
                if (cont.isActive) cont.resumeWithException(CameraUnavailable("Camera $id was taken by another app."))
                else onCameraLost(id, "disconnected")
            }

            override fun onError(device: CameraDevice, error: Int) {
                device.close()
                val msg = when (error) {
                    CameraDevice.StateCallback.ERROR_CAMERA_IN_USE -> "Camera $id is being used by another app."
                    CameraDevice.StateCallback.ERROR_MAX_CAMERAS_IN_USE -> "The phone refused to open both cameras at once."
                    CameraDevice.StateCallback.ERROR_CAMERA_DISABLED -> "Camera $id is disabled on this phone."
                    else -> "Camera $id failed (error $error)."
                }
                if (cont.isActive) cont.resumeWithException(CameraUnavailable(msg)) else onCameraLost(id, msg)
            }
        }, handler)
    }

    private suspend fun createSession(device: CameraDevice, surfaces: List<Surface>): CameraCaptureSession =
        suspendCancellableCoroutine { cont ->
            val outputs = surfaces.map { OutputConfiguration(it) }
            val sc = SessionConfiguration(SessionConfiguration.SESSION_REGULAR, outputs, executor,
                object : CameraCaptureSession.StateCallback() {
                    override fun onConfigured(session: CameraCaptureSession) {
                        if (cont.isActive) cont.resume(session) else session.close()
                    }

                    override fun onConfigureFailed(session: CameraCaptureSession) {
                        if (cont.isActive) cont.resumeWithException(
                            CameraUnavailable("Camera ${device.id} couldn't start with these settings. Try 720p.")
                        )
                    }
                })
            device.createCaptureSession(sc)
        }

    private fun repeatRequest(c: Cam, recording: Boolean) {
        val device = c.device ?: return
        val session = c.session ?: return
        val b = device.createCaptureRequest(if (recording) CameraDevice.TEMPLATE_RECORD else CameraDevice.TEMPLATE_PREVIEW)
        c.preview?.let { b.addTarget(it) }
        if (recording) c.encoderSurface?.let { b.addTarget(it) }
        c.fpsRange?.let { b.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, it) }
        if (c.zoom != 1f) b.set(CaptureRequest.CONTROL_ZOOM_RATIO, c.zoom)
        val wantStab = config.stabilization && CameraProbe.supportsVideoStab(c.chars)
        b.set(
            CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE,
            if (wantStab) CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_ON else CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_OFF
        )
        session.setRepeatingRequest(b.build(), c.stats, handler)
    }

    private fun onCameraLost(id: String, reason: String) {
        scope.launch {
            mutex.withLock {
                val saved = if (_status.value.state == State.RECORDING) runCatching { stopInternal() }.getOrNull() else null
                closeInternal()
                _status.value = Status(
                    state = State.ERROR,
                    message = "Camera $id stopped: $reason" + if (saved != null) " Footage up to that point was saved." else "",
                    freeBytes = freeBytes()
                )
            }
        }
    }

    // ---------------------------------------------------------------- recording

    suspend fun startRecording(newExtras: RecordExtras = RecordExtras()): Unit = mutex.withLock {
        val r = rear ?: return@withLock
        val f = front ?: return@withLock
        val size = recordSize ?: return@withLock
        if (_status.value.state != State.READY) return@withLock

        val needed = bytesPerMinute(size, config.audio)
        if (freeBytes() < MIN_FREE_BYTES + needed) {
            _status.value = _status.value.copy(message = "Not enough free space to record. Free up some storage first.")
            return@withLock
        }

        val dir = SessionRepository.newSessionDir(context)
        extras = newExtras
        bgCopied = runCatching {
            val bg = newExtras.background
            if (bg != null && bg.exists()) {
                bg.copyTo(File(dir, Session.BACKGROUND), overwrite = true)
                true
            } else false
        }.getOrDefault(false)
        withAudio = config.audio && ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        try {
            r.recorder = buildRecorder(File(dir, Session.REAR), size, r.encoderSurface!!, withAudio)
            f.recorder = buildRecorder(File(dir, Session.FRONT), size, f.encoderSurface!!, false)
            r.stats.reset()
            f.stats.reset()
            r.recorder!!.start()
            f.recorder!!.start()
            repeatRequest(r, recording = true)
            repeatRequest(f, recording = true)
            sessionDir = dir
            createdAt = System.currentTimeMillis()
            startedAt = SystemClock.elapsedRealtime()
            SessionRepository.save(buildSession(dir, 0, complete = false))
            _status.value = _status.value.copy(state = State.RECORDING, message = null, elapsedMs = 0)
            tickJob = scope.launch { tick() }
        } catch (e: Exception) {
            Log.e(TAG, "start failed", e)
            listOf(r, f).forEach { c -> runCatching { c.recorder?.release() }; c.recorder = null }
            dir.deleteRecursively()
            runCatching { repeatRequest(r, false); repeatRequest(f, false) }
            _status.value = _status.value.copy(state = State.READY, message = "Couldn't start recording: ${e.message}")
        }
    }

    suspend fun stopRecording(reason: String? = null): Session? = mutex.withLock {
        if (_status.value.state != State.RECORDING) return@withLock null
        val saved = stopInternal()
        _status.value = _status.value.copy(
            state = if (rear != null) State.READY else State.IDLE,
            message = reason ?: if (saved == null) "Recording failed. Nothing was saved." else null
        )
        saved
    }

    private fun buildRecorder(file: File, size: Size, surface: Surface, audio: Boolean): MediaRecorder =
        newRecorder().apply {
            if (audio) setAudioSource(MediaRecorder.AudioSource.CAMCORDER)
            setVideoSource(MediaRecorder.VideoSource.SURFACE)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setOutputFile(file.absolutePath)
            setVideoEncodingBitRate(bitrateFor(size))
            setVideoFrameRate(30)
            setVideoSize(size.width, size.height)
            setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            if (audio) {
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioEncodingBitRate(AUDIO_BITRATE)
                setAudioSamplingRate(48_000)
            }
            setInputSurface(surface)
            prepare()
        }

    private fun stopInternal(): Session? {
        tickJob?.cancel()
        tickJob = null
        _status.value = _status.value.copy(state = State.STOPPING)
        val r = rear
        val f = front
        val dir = sessionDir
        r?.let { runCatching { repeatRequest(it, false) } }
        f?.let { runCatching { repeatRequest(it, false) } }
        val rearOk = r?.recorder?.let { stopSafely(it) } ?: false
        val frontOk = f?.recorder?.let { stopSafely(it) } ?: false
        val duration = SystemClock.elapsedRealtime() - startedAt
        listOfNotNull(r, f).forEach { c -> runCatching { c.recorder?.release() }; c.recorder = null }
        sessionDir = null
        if (dir == null || r == null || f == null) return null
        if (!rearOk) File(dir, Session.REAR).delete()
        if (!frontOk) File(dir, Session.FRONT).delete()
        if (!rearOk && !frontOk) {
            dir.deleteRecursively()
            return null
        }
        val session = buildSession(dir, duration, complete = true)
        SessionRepository.save(session)
        return session
    }

    private fun stopSafely(m: MediaRecorder): Boolean = try {
        m.stop()
        true
    } catch (e: RuntimeException) {
        Log.w(TAG, "recorder stop failed", e)
        false
    }

    private suspend fun tick() {
        while (true) {
            delay(500)
            val s = _status.value
            if (s.state != State.RECORDING) return
            val r = rear
            val f = front
            val elapsed = SystemClock.elapsedRealtime() - startedAt
            val free = freeBytes()
            val thermal = power.currentThermalStatus
            _status.value = s.copy(
                elapsedMs = elapsed,
                fpsRear = r?.stats?.fps() ?: 0f,
                fpsFront = f?.stats?.fps() ?: 0f,
                droppedRear = r?.stats?.dropped ?: 0,
                droppedFront = f?.stats?.dropped ?: 0,
                thermal = thermal,
                freeBytes = free
            )
            val reason = when {
                free < MIN_FREE_BYTES -> "Stopped: storage is almost full."
                thermal >= PowerManager.THERMAL_STATUS_SEVERE -> "Stopped: the phone got too hot. Let it cool down."
                elapsed >= config.maxMinutes * 60_000L -> "Stopped: reached your ${config.maxMinutes} minute limit."
                else -> null
            }
            if (reason != null) {
                scope.launch { stopRecording(reason) }
                return
            }
        }
    }

    private fun buildSession(dir: File, duration: Long, complete: Boolean): Session {
        val r = rear!!
        val f = front!!
        val size = recordSize!!
        val offsetMs = if (r.realtimeClock && f.realtimeClock && r.stats.first > 0 && f.stats.first > 0)
            (f.stats.first - r.stats.first) / 1_000_000L else 0L
        return Session(
            dir = dir,
            createdAt = createdAt,
            durationMs = duration,
            lensMode = config.lensMode,
            rear = CamMeta(r.id, r.sensorOrientation, CameraProbe.horizontalFovDeg(r.chars, r.zoom), size.width, size.height, r.zoom),
            front = CamMeta(f.id, f.sensorOrientation, CameraProbe.horizontalFovDeg(f.chars, 1f), size.width, size.height, 1f),
            frontOffsetMs = offsetMs,
            fpsRear = r.stats.fps(),
            fpsFront = f.stats.fps(),
            droppedRear = r.stats.dropped,
            droppedFront = f.stats.dropped,
            hasAudio = withAudio,
            complete = complete,
            calibration = Calibration(
                mode = config.lensMode,
                fill = if (bgCopied) FillMode.BACKGROUND else FillMode.SOFT
            ),
            orientation = extras.orientation,
            bgCoverage = if (bgCopied) extras.bgCoverage else 0f
        )
    }

    private fun freeBytes(): Long = SessionRepository.root(context).usableSpace

    companion object {
        private const val TAG = "DualRecorder"
        private const val MAX_OPEN_ATTEMPTS = 4
        private val CAMERA_LOCK = Mutex()
        private const val MIN_FREE_BYTES = 300_000_000L
        private const val AUDIO_BITRATE = 128_000

        fun bitrateFor(size: Size): Int = if (size.height >= 1080) 16_000_000 else 8_000_000

        fun bytesPerMinute(size: Size, audio: Boolean): Long =
            (2L * bitrateFor(size) + if (audio) AUDIO_BITRATE else 0) / 8L * 60L
    }
}
