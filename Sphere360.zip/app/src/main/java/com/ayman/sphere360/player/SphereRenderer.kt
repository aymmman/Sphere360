package com.ayman.sphere360.player

import android.graphics.Bitmap
import android.graphics.SurfaceTexture
import android.hardware.SensorManager
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.util.Log
import android.view.Surface
import com.ayman.sphere360.geometry.SphereMath
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.tan

/**
 * Draws the sphere by casting a ray per pixel (no mesh, no seams from triangles).
 * Both camera videos arrive as external OES textures from MediaPlayer.
 */
class SphereRenderer(
    private val backgroundFile: java.io.File?,
    private val onSurfaces: (Surface, Surface) -> Unit,
    private val onError: (String) -> Unit
) : GLSurfaceView.Renderer {

    data class Params(
        val rear: SphereMath.Lens,
        val front: SphereMath.Lens,
        val fisheye: Boolean,
        val halfFovRad: Float,
        val blendRad: Float,
        val mirrorFront: Boolean,
        val fill: Int,
        val edge: Float,
        val bgYawRad: Float,
        val viewToWorld: FloatArray,
        val worldToDev: FloatArray,
        val stretchRear: Float = 1f,
        val stretchFront: Float = 1f
    )

    @Volatile var params: Params? = null
    @Volatile var yawDeg = 0f
    @Volatile var pitchDeg = 0f
    @Volatile var fovDeg = 85f
    @Volatile var gyro = false

    private val rotLock = Any()
    private val rotVec = FloatArray(5)
    private var rotLen = 0
    @Volatile private var recenter = true
    private var refYaw = 0f

    @Volatile private var exportWidth = 4096
    @Volatile private var exportCallback: ((Bitmap?) -> Unit)? = null

    private var screenProg = 0
    private var equiProg = 0
    private val tex = IntArray(2)
    private val bgTex = IntArray(1)
    private var hasBg = false
    private var stRear: SurfaceTexture? = null
    private var stFront: SurfaceTexture? = null
    private var surfaceRear: Surface? = null
    private var surfaceFront: Surface? = null
    private val stRearM = FloatArray(16)
    private val stFrontM = FloatArray(16)
    private var vw = 1
    private var vh = 1

    private val base = FloatArray(16)
    private val yawM = FloatArray(16)
    private val view = FloatArray(16)
    private val invView = FloatArray(16)
    private val rotM = FloatArray(16)
    private val tmpV = FloatArray(4)
    private val fwd = FloatArray(4)

    private val quad: FloatBuffer = ByteBuffer.allocateDirect(8 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
        put(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f))
        position(0)
    }

    fun setRotationVector(v: FloatArray) {
        synchronized(rotLock) {
            val n = min(v.size, 5)
            System.arraycopy(v, 0, rotVec, 0, n)
            rotLen = n
        }
    }

    fun requestRecenter() { recenter = true }

    /** Renders one equirectangular 360 frame (width x width/2) on the GL thread. */
    fun requestEquirect(width: Int, callback: (Bitmap?) -> Unit) {
        exportWidth = width
        exportCallback = callback
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        try {
            screenProg = GlUtil.program(Shaders.VERTEX, Shaders.SCREEN_FRAGMENT)
            equiProg = GlUtil.program(Shaders.VERTEX, Shaders.EQUIRECT_FRAGMENT)
        } catch (e: Exception) {
            Log.e(TAG, "shader error", e)
            screenProg = 0
            equiProg = 0
            onError("Graphics setup failed: ${e.message}")
            return
        }
        GLES20.glGenTextures(2, tex, 0)
        for (t in tex) {
            GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, t)
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        }
        loadBackground()
        releaseSurfaces()
        val a = SurfaceTexture(tex[0])
        val b = SurfaceTexture(tex[1])
        stRear = a
        stFront = b
        Matrix.setIdentityM(stRearM, 0)
        Matrix.setIdentityM(stFrontM, 0)
        val sa = Surface(a)
        val sb = Surface(b)
        surfaceRear = sa
        surfaceFront = sb
        onSurfaces(sa, sb)
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        vw = width.coerceAtLeast(1)
        vh = height.coerceAtLeast(1)
        GLES20.glViewport(0, 0, vw, vh)
    }

    override fun onDrawFrame(gl: GL10?) {
        runCatching { stRear?.updateTexImage(); stRear?.getTransformMatrix(stRearM) }
        runCatching { stFront?.updateTexImage(); stFront?.getTransformMatrix(stFrontM) }
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
        GLES20.glViewport(0, 0, vw, vh)
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        val p = params ?: return
        if (screenProg == 0) return
        computeView()
        draw(screenProg, p, screen = true)
        exportCallback?.let { cb ->
            exportCallback = null
            val bmp = runCatching { renderEquirect(p) }.onFailure { Log.e(TAG, "export failed", it) }.getOrNull()
            cb(bmp)
        }
    }

    private fun loadBackground() {
        hasBg = false
        val f = backgroundFile ?: return
        if (!f.exists()) return
        val bmp = runCatching { android.graphics.BitmapFactory.decodeFile(f.absolutePath) }.getOrNull() ?: return
        GLES20.glGenTextures(1, bgTex, 0)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE2)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, bgTex[0])
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_REPEAT)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        android.opengl.GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0)
        bmp.recycle()
        hasBg = true
    }

    fun releaseGl() {
        if (hasBg) GLES20.glDeleteTextures(1, bgTex, 0)
        hasBg = false
        releaseSurfaces()
        if (screenProg != 0) GLES20.glDeleteProgram(screenProg)
        if (equiProg != 0) GLES20.glDeleteProgram(equiProg)
        screenProg = 0
        equiProg = 0
    }

    private fun releaseSurfaces() {
        runCatching { surfaceRear?.release() }
        runCatching { surfaceFront?.release() }
        runCatching { stRear?.release() }
        runCatching { stFront?.release() }
        surfaceRear = null; surfaceFront = null; stRear = null; stFront = null
    }

    private fun computeView() {
        var useGyro = false
        if (gyro) {
            synchronized(rotLock) {
                if (rotLen >= 3) {
                    SensorManager.getRotationMatrixFromVector(rotM, rotVec.copyOf(rotLen))
                    useGyro = true
                }
            }
        }
        if (useGyro) {
            // rotM (as read by GL) maps Android world -> device; OURS_TO_ANDROID maps our Y-up world into it
            Matrix.multiplyMM(base, 0, rotM, 0, OURS_TO_ANDROID, 0)
        } else {
            Matrix.setRotateM(base, 0, pitchDeg, 1f, 0f, 0f)
        }
        if (recenter && (!gyro || useGyro)) {
            recenter = false
            yawDeg = 0f
            if (useGyro) {
                Matrix.transposeM(invView, 0, base, 0)
                tmpV[0] = 0f; tmpV[1] = 0f; tmpV[2] = -1f; tmpV[3] = 0f
                Matrix.multiplyMV(fwd, 0, invView, 0, tmpV, 0)
                refYaw = -Math.toDegrees(atan2(fwd[0].toDouble(), (-fwd[2]).toDouble())).toFloat()
            } else {
                pitchDeg = 0f
                refYaw = 0f
                Matrix.setIdentityM(base, 0)
            }
        }
        Matrix.setRotateM(yawM, 0, yawDeg + refYaw, 0f, 1f, 0f)
        Matrix.multiplyMM(view, 0, base, 0, yawM, 0)
        Matrix.transposeM(invView, 0, view, 0)
    }

    private fun draw(program: Int, p: Params, screen: Boolean) {
        GLES20.glUseProgram(program)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex[0])
        GLES20.glActiveTexture(GLES20.GL_TEXTURE1)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex[1])
        GLES20.glActiveTexture(GLES20.GL_TEXTURE2)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, if (hasBg) bgTex[0] else 0)

        fun u(name: String) = GLES20.glGetUniformLocation(program, name)
        GLES20.glUniform1i(u("uRear"), 0)
        GLES20.glUniform1i(u("uFront"), 1)
        GLES20.glUniform1i(u("uBg"), 2)
        GLES20.glUniformMatrix4fv(u("uViewToWorld"), 1, false, p.viewToWorld, 0)
        GLES20.glUniformMatrix4fv(u("uWorldToDev"), 1, false, p.worldToDev, 0)
        GLES20.glUniform1i(u("uFill"), p.fill)
        GLES20.glUniform1f(u("uEdge"), p.edge)
        GLES20.glUniform1f(u("uHasBg"), if (hasBg) 1f else 0f)
        GLES20.glUniform1f(u("uBgYaw"), p.bgYawRad)
        GLES20.glUniform2f(u("uStretch"), p.stretchRear, p.stretchFront)
        GLES20.glUniformMatrix4fv(u("uStRear"), 1, false, stRearM, 0)
        GLES20.glUniformMatrix4fv(u("uStFront"), 1, false, stFrontM, 0)
        GLES20.glUniform1i(u("uFisheye"), if (p.fisheye) 1 else 0)
        setLens(u("uRotRear"), u("uTanRear"), u("uCircleRear"), p.rear)
        setLens(u("uRotFront"), u("uTanFront"), u("uCircleFront"), p.front)
        GLES20.glUniform1f(u("uHalfFov"), p.halfFovRad)
        GLES20.glUniform1f(u("uBlend"), p.blendRad.coerceAtLeast(0.001f))
        GLES20.glUniform1f(u("uMirrorFront"), if (p.mirrorFront) -1f else 1f)
        if (screen) {
            GLES20.glUniformMatrix4fv(u("uInvView"), 1, false, invView, 0)
            val ty = tan(Math.toRadians(fovDeg / 2.0)).toFloat()
            GLES20.glUniform2f(u("uTanView"), ty * vw / vh.toFloat(), ty)
        }
        val loc = GLES20.glGetAttribLocation(program, "aPos")
        quad.position(0)
        GLES20.glEnableVertexAttribArray(loc)
        GLES20.glVertexAttribPointer(loc, 2, GLES20.GL_FLOAT, false, 0, quad)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(loc)
    }

    private fun setLens(rotLoc: Int, tanLoc: Int, circleLoc: Int, lens: SphereMath.Lens) {
        val a = Math.toRadians(lens.rotDeg.toDouble())
        GLES20.glUniform2f(rotLoc, cos(a).toFloat(), sin(a).toFloat())
        GLES20.glUniform2f(tanLoc, lens.tanW, lens.tanH)
        GLES20.glUniform2f(circleLoc, lens.circleU, lens.circleV)
    }

    private fun renderEquirect(p: Params): Bitmap? {
        if (equiProg == 0) return null
        val maxTex = IntArray(1)
        val maxVp = IntArray(2)
        GLES20.glGetIntegerv(GLES20.GL_MAX_TEXTURE_SIZE, maxTex, 0)
        GLES20.glGetIntegerv(GLES20.GL_MAX_VIEWPORT_DIMS, maxVp, 0)
        val w = minOf(exportWidth, maxTex[0], maxVp[0]).coerceAtLeast(512) / 2 * 2
        val h = w / 2

        val t = IntArray(1)
        val fbo = IntArray(1)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE3)
        GLES20.glGenTextures(1, t, 0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, t[0])
        GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, w, h, 0, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, null)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glGenFramebuffers(1, fbo, 0)
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fbo[0])
        GLES20.glFramebufferTexture2D(GLES20.GL_FRAMEBUFFER, GLES20.GL_COLOR_ATTACHMENT0, GLES20.GL_TEXTURE_2D, t[0], 0)
        try {
            if (GLES20.glCheckFramebufferStatus(GLES20.GL_FRAMEBUFFER) != GLES20.GL_FRAMEBUFFER_COMPLETE) return null
            GLES20.glViewport(0, 0, w, h)
            draw(equiProg, p, screen = false)
            val buf = ByteBuffer.allocateDirect(w * h * 4).order(ByteOrder.nativeOrder())
            GLES20.glReadPixels(0, 0, w, h, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, buf)
            buf.rewind()
            val raw = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            raw.copyPixelsFromBuffer(buf)
            val flip = android.graphics.Matrix().apply { preScale(1f, -1f) }
            val out = Bitmap.createBitmap(raw, 0, 0, w, h, flip, false)
            if (out != raw) raw.recycle()
            return out
        } finally {
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
            GLES20.glDeleteFramebuffers(1, fbo, 0)
            GLES20.glDeleteTextures(1, t, 0)
            GLES20.glViewport(0, 0, vw, vh)
        }
    }

    companion object {
        private const val TAG = "SphereRenderer"

        /** Column-major: our X->X, our Y (up)->Android Z (up), our Z->Android -Y. */
        val OURS_TO_ANDROID = floatArrayOf(
            1f, 0f, 0f, 0f,
            0f, 0f, 1f, 0f,
            0f, -1f, 0f, 0f,
            0f, 0f, 0f, 1f
        )
    }
}

object GlUtil {
    fun program(vertex: String, fragment: String): Int {
        val v = shader(GLES20.GL_VERTEX_SHADER, vertex)
        val f = shader(GLES20.GL_FRAGMENT_SHADER, fragment)
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, v)
        GLES20.glAttachShader(p, f)
        GLES20.glLinkProgram(p)
        val status = IntArray(1)
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, status, 0)
        GLES20.glDeleteShader(v)
        GLES20.glDeleteShader(f)
        if (status[0] == 0) {
            val log = GLES20.glGetProgramInfoLog(p)
            GLES20.glDeleteProgram(p)
            throw RuntimeException("link: $log")
        }
        return p
    }

    private fun shader(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        val status = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, status, 0)
        if (status[0] == 0) {
            val log = GLES20.glGetShaderInfoLog(s)
            GLES20.glDeleteShader(s)
            throw RuntimeException("compile: $log")
        }
        return s
    }
}
