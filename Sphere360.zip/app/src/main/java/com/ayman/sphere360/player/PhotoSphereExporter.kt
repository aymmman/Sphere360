package com.ayman.sphere360.player

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.provider.MediaStore
import java.io.ByteArrayOutputStream

/**
 * Saves an equirectangular JPEG with Google Photo Sphere (GPano) metadata,
 * so Google Photos, Facebook and others open it as a real 360 photo.
 */
object PhotoSphereExporter {

    fun save(context: Context, bitmap: Bitmap, name: String): Uri? {
        val baos = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 92, baos)
        val jpeg = insertXmp(baos.toByteArray(), xmp(bitmap.width, bitmap.height))

        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "$name.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Sphere360")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        return try {
            val out = resolver.openOutputStream(uri) ?: throw IllegalStateException("no output stream")
            out.use { it.write(jpeg) }
            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            uri
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            null
        }
    }

    private fun xmp(w: Int, h: Int): String =
        "<?xpacket begin=\"\uFEFF\" id=\"W5M0MpCehiHzreSzNTczkc9d\"?>" +
            "<x:xmpmeta xmlns:x=\"adobe:ns:meta/\">" +
            "<rdf:RDF xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\">" +
            "<rdf:Description rdf:about=\"\" xmlns:GPano=\"http://ns.google.com/photos/1.0/panorama/\"" +
            " GPano:ProjectionType=\"equirectangular\"" +
            " GPano:UsePanoramaViewer=\"True\"" +
            " GPano:FullPanoWidthPixels=\"$w\"" +
            " GPano:FullPanoHeightPixels=\"$h\"" +
            " GPano:CroppedAreaImageWidthPixels=\"$w\"" +
            " GPano:CroppedAreaImageHeightPixels=\"$h\"" +
            " GPano:CroppedAreaLeftPixels=\"0\"" +
            " GPano:CroppedAreaTopPixels=\"0\"/>" +
            "</rdf:RDF></x:xmpmeta><?xpacket end=\"w\"?>"

    fun insertXmp(jpeg: ByteArray, xmp: String): ByteArray {
        val header = "http://ns.adobe.com/xap/1.0/".toByteArray(Charsets.US_ASCII) + byteArrayOf(0)
        val payload = header + xmp.toByteArray(Charsets.UTF_8)
        val len = payload.size + 2
        require(len <= 0xFFFF) { "XMP too large" }
        val segment = byteArrayOf(0xFF.toByte(), 0xE1.toByte(), (len shr 8).toByte(), (len and 0xFF).toByte()) + payload
        var at = 2
        if (jpeg.size > 6 && jpeg[2] == 0xFF.toByte() && jpeg[3] == 0xE0.toByte()) {
            val app0 = ((jpeg[4].toInt() and 0xFF) shl 8) or (jpeg[5].toInt() and 0xFF)
            at = 4 + app0
        }
        return jpeg.copyOfRange(0, at) + segment + jpeg.copyOfRange(at, jpeg.size)
    }
}
