package com.ayman.sphere360.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Night-sky palette: midnight navy, horizon amber, record red, sky blue.
val Midnight = Color(0xFF0E1420)
val Horizon = Color(0xFFF2A93B)
val RecordRed = Color(0xFFE5484D)
val Sky = Color(0xFF7CC4FA)

private val Colors = darkColorScheme(
    primary = Horizon,
    onPrimary = Color(0xFF2A1A00),
    primaryContainer = Color(0xFF3A2A10),
    onPrimaryContainer = Color(0xFFFFDDB0),
    secondary = Sky,
    onSecondary = Color(0xFF00243D),
    tertiary = RecordRed,
    background = Midnight,
    onBackground = Color(0xFFE8EDF5),
    surface = Color(0xFF162033),
    onSurface = Color(0xFFE8EDF5),
    surfaceVariant = Color(0xFF1F2A40),
    onSurfaceVariant = Color(0xFF9DAAC0),
    surfaceContainer = Color(0xFF162033),
    surfaceContainerHigh = Color(0xFF1F2A40),
    outline = Color(0xFF34425C),
    error = Color(0xFFFF7B7F)
)

@Composable
fun Sphere360Theme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Colors, typography = Typography(), content = content)
}
