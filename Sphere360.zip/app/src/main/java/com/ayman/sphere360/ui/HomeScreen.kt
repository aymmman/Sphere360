package com.ayman.sphere360.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ayman.sphere360.camera.CameraProbe
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun HomeScreen(onRecord: () -> Unit, onLibrary: () -> Unit, onDiagnostics: () -> Unit) {
    val context = LocalContext.current
    val support by produceState<Boolean?>(initialValue = null) {
        value = withContext(Dispatchers.IO) { runCatching { CameraProbe.supportsFrontBack(context) }.getOrDefault(false) }
    }
    val colors = MaterialTheme.colorScheme

    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        Spacer(Modifier.height(16.dp))
        Text("Sphere 360", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text(
            "Record what's in front of you and behind you at once, then look around it.",
            style = MaterialTheme.typography.bodyLarge,
            color = colors.onSurfaceVariant
        )
        Spacer(Modifier.height(18.dp))
        when (support) {
            null -> Pill("Checking your cameras")
            true -> Pill("Both cameras can record together", colors.secondary.copy(alpha = 0.15f), colors.secondary)
            false -> Pill("This phone can't run both cameras together", colors.error.copy(alpha = 0.15f), colors.error)
        }
        Spacer(Modifier.height(24.dp))

        Surface(
            onClick = onRecord,
            shape = RoundedCornerShape(28.dp),
            modifier = Modifier.fillMaxWidth().height(180.dp)
        ) {
            Box(
                Modifier.fillMaxSize().background(
                    Brush.linearGradient(listOf(Color(0xFF263552), Color(0xFF151D2E), Color(0xFF3A2A10)))
                ).padding(22.dp)
            ) {
                Column(Modifier.align(Alignment.BottomStart)) {
                    Text("Start recording", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
                    Text("Front and rear cameras together", style = MaterialTheme.typography.bodyMedium, color = colors.onSurfaceVariant)
                }
                Box(
                    Modifier.align(Alignment.TopEnd).size(56.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Box(Modifier.size(26.dp).clip(CircleShape).background(RecordRed))
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        ActionRow(Icons.Filled.VideoLibrary, "Library", "Watch recordings in 360 and save 360 photos", onLibrary)
        Spacer(Modifier.height(12.dp))
        ActionRow(Icons.Filled.Memory, "Camera check", "See what your phone supports and copy a report", onDiagnostics)
        Spacer(Modifier.weight(1f))
        Text(
            "Everything stays on your phone. No account, no uploads.",
            style = MaterialTheme.typography.bodySmall,
            color = colors.onSurfaceVariant
        )
    }
}

@Composable
private fun ActionRow(icon: ImageVector, title: String, subtitle: String, onClick: () -> Unit) {
    Surface(onClick = onClick, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Start) {
            Box(
                Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center
            ) { Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary) }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
