package com.ayman.sphere360.camera

import android.content.Context
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.params.OutputConfiguration
import android.hardware.camera2.params.SessionConfiguration
import android.media.MediaRecorder
import android.os.Build
import android.os.PowerManager
import android.util.Range
import android.util.Size
import com.ayman.sphere360.data.SessionRepository
import java.util.Locale
import java.util.concurrent.Executor
import kotlin.math.atan
import kotlin.math.max
import kotlin.math.tan

class CameraUnavailable(message: String) : Exception(message)

/** Reads what the phone really supports. Nothing here is assumed. */
object CameraProbe {

    private fun facing(ch: CameraCharacteristics): Int? = ch.get(CameraCharacteristics.LENS_FACING)

    fun minZoom(ch: CameraCharacteristics): Float {
        val lower = ch.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE)?.lower ?: 1f
        return if (lower < 1f) lower else 1f
    }

    /** Horizontal FOV along the sensor's long side, adjusted for a zoom ratio. */
    fun horizontalFovDeg(ch: CameraCharacteristics, zoom: Float = 1f): Float {
        val size = ch.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE) ?: return 70f
        val focal = ch.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull() ?: return 70f
        var width = max(size.width, size.height)
        val pixel = ch.get(CameraCharacteristics.SENSOR_INFO_PIXEL_ARRAY_SIZE)
        val active = ch.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE)
        if (pixel != null && active != null) {
            width *= max(active.width(), active.height()).toFloat() / max(pixel.width, pixel.height).toFloat()
        }
        val halfTan = (width / (2f * focal)) / zoom
        return Math.toDegrees(2.0 * atan(halfTan.toDouble())).toFloat()
    }

    /** Picks a rear + front pair the phone allows to run together, preferring the widest rear view. */
    fun findFrontBackPair(mgr: CameraManager): Pair<String, String>? {
        val sets = try { mgr.concurrentCameraIds } catch (e: Exception) { emptySet() }
        var best: Pair<String, String>? = null
        var bestFov = -1f
        for (set in sets) {
            val chars = set.associateWith { runCatching { mgr.getCameraCharacteristics(it) }.getOrNull() }
            val fronts = set.filter { chars[it]?.let { c -> facing(c) } == CameraCharacteristics.LENS_FACING_FRONT }
            val backs = set.filter { chars[it]?.let { c -> facing(c) } == CameraCharacteristics.LENS_FACING_BACK }
            if (fronts.isEmpty()) continue
            for (b in backs) {
                val ch = chars[b] ?: continue
                val fov = horizontalFovDeg(ch, minZoom(ch))
                if (fov > bestFov) {
                    bestFov = fov
                    best = b to fronts.first()
                }
            }
        }
        return best
    }

    fun supportsFrontBack(context: Context): Boolean =
        findFrontBackPair(context.getSystemService(CameraManager::class.java)) != null

    fun supportsRecorderSize(ch: CameraCharacteristics, size: Size): Boolean =
        ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            ?.getOutputSizes(MediaRecorder::class.java)?.contains(size) == true

    fun supportsVideoStab(ch: CameraCharacteristics): Boolean =
        ch.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES)
            ?.contains(CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_ON) == true

    fun fps30(ch: CameraCharacteristics): Range<Int>? {
        val ranges = ch.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES) ?: return null
        return ranges.firstOrNull { it.lower == 30 && it.upper == 30 }
            ?: ranges.filter { it.upper == 30 }.maxByOrNull { it.lower }
            ?: ranges.filter { it.contains(30) }.minByOrNull { it.upper - it.lower }
    }

    fun choosePreviewSize(vararg chars: CameraCharacteristics): Size {
        val target = Size(1280, 720)
        val all = chars.map {
            it.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                ?.getOutputSizes(SurfaceTexture::class.java)?.toList() ?: emptyList()
        }
        if (all.all { target in it }) return target
        val common = all.firstOrNull().orEmpty().filter { s ->
            all.all { s in it } && s.width * 9 == s.height * 16 && s.width <= 1280
        }
        return common.maxByOrNull { it.width } ?: Size(960, 540)
    }

    /** true / false from the phone, or null if the phone can't answer (we then just try). */
    fun isConcurrentSupported(mgr: CameraManager, rearId: String, frontId: String, preview: Size, record: Size): Boolean? {
        return try {
            val exec = Executor { it.run() }
            val cb = object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(session: CameraCaptureSession) {}
                override fun onConfigureFailed(session: CameraCaptureSession) {}
            }
            fun cfg() = SessionConfiguration(
                SessionConfiguration.SESSION_REGULAR,
                listOf(
                    OutputConfiguration(preview, SurfaceTexture::class.java),
                    OutputConfiguration(record, SurfaceTexture::class.java)
                ),
                exec, cb
            )
            mgr.isConcurrentSessionConfigurationSupported(mapOf(rearId to cfg(), frontId to cfg()))
        } catch (e: Exception) {
            null
        }
    }

    private fun facingName(ch: CameraCharacteristics) = when (facing(ch)) {
        CameraCharacteristics.LENS_FACING_BACK -> "rear"
        CameraCharacteristics.LENS_FACING_FRONT -> "front"
        CameraCharacteristics.LENS_FACING_EXTERNAL -> "external"
        else -> "unknown"
    }

    private fun levelName(level: Int?) = when (level) {
        CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_LEGACY -> "legacy"
        CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_LIMITED -> "limited"
        CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_FULL -> "full"
        CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_3 -> "level 3"
        CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_EXTERNAL -> "external"
        else -> "unknown"
    }

    /** Plain-text report the user can copy and share for troubleshooting. */
    fun report(context: Context): String {
        val mgr = context.getSystemService(CameraManager::class.java)
        val sb = StringBuilder()
        sb.appendLine("Sphere 360 camera report (app 0.3.0)")
        sb.appendLine("Device: ${Build.MANUFACTURER} ${Build.MODEL} (${Build.DEVICE})")
        sb.appendLine("Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        sb.appendLine()
        val ids = try { mgr.cameraIdList.toList() } catch (e: Exception) {
            sb.appendLine("Could not list cameras: ${e.message}")
            emptyList()
        }
        for (id in ids) {
            val ch = runCatching { mgr.getCameraCharacteristics(id) }.getOrNull() ?: continue
            sb.appendLine("Camera $id (${facingName(ch)})")
            sb.appendLine("  sensor orientation: ${ch.get(CameraCharacteristics.SENSOR_ORIENTATION)}")
            sb.appendLine("  horizontal FOV at 1x: " + String.format(Locale.US, "%.1f deg", horizontalFovDeg(ch)))
            ch.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE)?.let {
                sb.appendLine("  zoom range: ${it.lower}x to ${it.upper}x" +
                    String.format(Locale.US, " (widest FOV %.1f deg)", horizontalFovDeg(ch, minZoom(ch))))
            }
            sb.appendLine("  hardware level: ${levelName(ch.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL))}")
            val caps = ch.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES) ?: IntArray(0)
            if (caps.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_LOGICAL_MULTI_CAMERA)) {
                sb.appendLine("  logical multi-camera, physical lenses: ${ch.physicalCameraIds.joinToString()}")
            }
            val sizes = ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                ?.getOutputSizes(MediaRecorder::class.java)
                ?.filter { it.width * 9 == it.height * 16 }
                ?.take(6)
            sb.appendLine("  16:9 video sizes: ${sizes?.joinToString { "${it.width}x${it.height}" } ?: "none"}")
            val realtime = ch.get(CameraCharacteristics.SENSOR_INFO_TIMESTAMP_SOURCE) ==
                CameraMetadata.SENSOR_INFO_TIMESTAMP_SOURCE_REALTIME
            sb.appendLine("  stabilization: ${if (supportsVideoStab(ch)) "yes" else "no"}, clock: ${if (realtime) "realtime" else "unknown"}")
        }
        sb.appendLine()
        val sets = try { mgr.concurrentCameraIds } catch (e: Exception) { emptySet() }
        sb.appendLine("Concurrent camera sets: " +
            if (sets.isEmpty()) "none reported" else sets.joinToString { it.joinToString(prefix = "[", postfix = "]") })
        val pair = findFrontBackPair(mgr)
        if (pair == null) {
            sb.appendLine("Front + rear together: NOT available to apps")
        } else {
            sb.appendLine("Front + rear together: rear ${pair.first} + front ${pair.second}")
            val prev = choosePreviewSize(mgr.getCameraCharacteristics(pair.first), mgr.getCameraCharacteristics(pair.second))
            sb.appendLine("  preview size: ${prev.width}x${prev.height}")
            for (s in listOf(Size(1920, 1080), Size(1280, 720))) {
                val r = isConcurrentSupported(mgr, pair.first, pair.second, prev, s)
                val text = when (r) {
                    true -> "supported"
                    false -> "not supported"
                    null -> "phone didn't say (app will try)"
                }
                sb.appendLine("  record ${s.width}x${s.height}: $text")
            }
        }
        sb.appendLine()
        val pm = context.getSystemService(PowerManager::class.java)
        sb.appendLine("Thermal status: ${pm.currentThermalStatus}")
        sb.appendLine("Free storage: ${SessionRepository.root(context).usableSpace / 1_000_000} MB")
        return sb.toString()
    }
}
