package com.ayman.sphere360.camera

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlin.math.min

/**
 * Phone orientation relative to the real world (north + gravity), so the room scan and
 * recordings made minutes apart line up. Matrix is 16 floats, read by OpenGL as world-to-device.
 */
class OrientationTracker(context: Context) : SensorEventListener {
    private val sm = context.getSystemService(SensorManager::class.java)
    private val sensor: Sensor? = sm?.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
    @Volatile private var latest: FloatArray? = null
    var listener: ((FloatArray) -> Unit)? = null

    val available: Boolean get() = sensor != null

    fun start() {
        val s = sensor ?: return
        sm?.registerListener(this, s, SensorManager.SENSOR_DELAY_GAME)
    }

    fun stop() {
        sm?.unregisterListener(this)
    }

    fun matrix(): FloatArray? = latest?.copyOf()

    override fun onSensorChanged(event: SensorEvent) {
        val m = FloatArray(16)
        // Some phones send 5 values; the first 4 are the rotation quaternion.
        SensorManager.getRotationMatrixFromVector(m, event.values.copyOf(min(4, event.values.size)))
        latest = m
        listener?.invoke(m)
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}
