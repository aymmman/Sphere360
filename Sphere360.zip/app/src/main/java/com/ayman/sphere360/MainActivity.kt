package com.ayman.sphere360

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.ayman.sphere360.ui.DiagnosticsScreen
import com.ayman.sphere360.ui.HomeScreen
import com.ayman.sphere360.ui.LibraryScreen
import com.ayman.sphere360.ui.PlayerScreen
import com.ayman.sphere360.ui.RecordScreen
import com.ayman.sphere360.ui.ScanScreen
import com.ayman.sphere360.ui.Sphere360Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { Sphere360Theme { AppRoot() } }
    }
}

private sealed interface Screen {
    data object Home : Screen
    data object Record : Screen
    data object Library : Screen
    data object Diagnostics : Screen
    data object Scan : Screen
    data class Player(val dir: String) : Screen
}

@Composable
private fun AppRoot() {
    val context = LocalContext.current
    var stack by remember { mutableStateOf(listOf<Screen>(Screen.Home)) }

    fun push(s: Screen) { stack = stack + s }
    fun pop() { if (stack.size > 1) stack = stack.dropLast(1) }

    BackHandler(enabled = stack.size > 1) { pop() }

    val permissions = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        if (result[Manifest.permission.CAMERA] == true) push(Screen.Record)
        else Toast.makeText(context, "Sphere 360 needs camera access to record.", Toast.LENGTH_LONG).show()
    }

    fun openRecorder() {
        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        if (granted) push(Screen.Record)
        else permissions.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
    }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        val screen = stack.last()
        key(stack.size, screen) {
            when (screen) {
                Screen.Home -> HomeScreen(
                    onRecord = { openRecorder() },
                    onLibrary = { push(Screen.Library) },
                    onDiagnostics = { push(Screen.Diagnostics) }
                )
                Screen.Record -> RecordScreen(
                    onBack = { pop() },
                    onOpenSession = { dir -> stack = stack.dropLast(1) + Screen.Player(dir) },
                    onScan = { push(Screen.Scan) }
                )
                Screen.Scan -> ScanScreen(onDone = { pop() })
                Screen.Library -> LibraryScreen(onBack = { pop() }, onOpen = { dir -> push(Screen.Player(dir)) })
                Screen.Diagnostics -> DiagnosticsScreen(onBack = { pop() })
                is Screen.Player -> PlayerScreen(sessionDir = screen.dir, onBack = { pop() })
            }
        }
    }
}
