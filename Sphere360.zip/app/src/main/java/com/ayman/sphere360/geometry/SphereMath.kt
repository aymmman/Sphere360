package com.ayman.sphere360.geometry

import kotlin.math.PI
import kotlin.math.acos
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

/**
 * Pure geometry, mirrored 1:1 by the GPU shader. Used to compute real sphere coverage
 * (no invented numbers) and covered by unit tests.
 *
 * World: +Y up, -Z = where the rear camera points (in front of you), +Z = behind you.
 * Camera-local frame: x right, y up, z along the lens axis.
 */
object SphereMath {

    data class Lens(
        val rotDeg: Float,   // rotation from upright view to raw sensor buffer
        val tanW: Float,     // tan(half FOV) along buffer width (no lens mode)
        val tanH: Float,     // tan(half FOV) along buffer height
        val circleU: Float,  // fisheye image circle radius in u units
        val circleV: Float   // fisheye image circle radius in v units
    )

    fun lensFor(hFovDeg: Float, width: Int, height: Int, rotDeg: Float, circleScale: Float): Lens {
        val tanW = tan(Math.toRadians(hFovDeg / 2.0)).toFloat()
        val aspect = height.toFloat() / width.toFloat()
        return Lens(rotDeg, tanW, tanW * aspect, 0.5f * circleScale * aspect, 0.5f * circleScale)
    }

    fun covered(lx: Double, ly: Double, lz: Double, lens: Lens, fisheye: Boolean, halfFovRad: Double): Boolean {
        val a = Math.toRadians(lens.rotDeg.toDouble())
        val c = cos(a)
        val s = sin(a)
        if (!fisheye) {
            if (lz <= 1e-3) return false
            val px = lx / lz
            val py = ly / lz
            val rx = px * c - py * s
            val ry = px * s + py * c
            val u = 0.5 + 0.5 * rx / lens.tanW
            val v = 0.5 + 0.5 * ry / lens.tanH
            return u in 0.0..1.0 && v in 0.0..1.0
        }
        val theta = acos(lz.coerceIn(-1.0, 1.0))
        if (theta > halfFovRad) return false
        val len = hypot(lx, ly)
        val dx = if (len > 1e-9) lx / len else 0.0
        val dy = if (len > 1e-9) ly / len else 0.0
        val rx = dx * c - dy * s
        val ry = dx * s + dy * c
        val r = theta / halfFovRad
        val u = 0.5 + r * rx * lens.circleU
        val v = 0.5 + r * ry * lens.circleV
        return u in 0.0..1.0 && v in 0.0..1.0
    }

    /** Fraction of the full sphere that real camera pixels cover (0..1). */
    fun coverage(
        rear: Lens,
        front: Lens,
        fisheye: Boolean,
        halfFovRad: Double,
        mirrorFront: Boolean,
        samples: Int = 20_000
    ): Float {
        val golden = PI * (3.0 - sqrt(5.0))
        val m = if (mirrorFront) -1.0 else 1.0
        var hit = 0
        for (i in 0 until samples) {
            val y = 1.0 - 2.0 * (i + 0.5) / samples
            val r = sqrt(max(0.0, 1.0 - y * y))
            val phi = i * golden
            val x = cos(phi) * r
            val z = sin(phi) * r
            val rearHit = covered(x, y, -z, rear, fisheye, halfFovRad)
            val frontHit = covered(-x * m, y, z, front, fisheye, halfFovRad)
            if (rearHit || frontHit) hit++
        }
        return hit.toFloat() / samples
    }
}
