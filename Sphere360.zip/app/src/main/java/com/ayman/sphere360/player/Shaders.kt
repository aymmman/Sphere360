package com.ayman.sphere360.player

/**
 * One shading function, two entry points: the on-screen viewer and the equirectangular
 * 360 photo export. Mirrors SphereMath exactly so coverage numbers match what you see.
 */
object Shaders {

    const val VERTEX = """
attribute vec2 aPos;
varying vec2 vNdc;
void main() {
    vNdc = aPos;
    gl_Position = vec4(aPos, 0.0, 1.0);
}
"""

    private const val COMMON = """#extension GL_OES_EGL_image_external : require
precision highp float;
varying vec2 vNdc;
uniform samplerExternalOES uRear;
uniform samplerExternalOES uFront;
uniform mat4 uStRear;
uniform mat4 uStFront;
uniform int uFisheye;
uniform vec2 uRotRear;
uniform vec2 uRotFront;
uniform vec2 uTanRear;
uniform vec2 uTanFront;
uniform vec2 uCircleRear;
uniform vec2 uCircleFront;
uniform float uHalfFov;
uniform float uBlend;
uniform float uMirrorFront;

vec2 rot2(vec2 p, vec2 cs) {
    return vec2(p.x * cs.x - p.y * cs.y, p.x * cs.y + p.y * cs.x);
}

vec3 mapNormal(vec3 l, vec2 cs, vec2 tanHalf) {
    if (l.z <= 0.001) return vec3(0.0);
    vec2 p = rot2(l.xy / l.z, cs);
    vec2 uv = 0.5 + 0.5 * p / tanHalf;
    if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) return vec3(0.0);
    return vec3(uv, 1.0);
}

vec3 mapFisheye(vec3 l, vec2 cs, vec2 circle) {
    float theta = acos(clamp(l.z, -1.0, 1.0));
    if (theta > uHalfFov) return vec3(0.0);
    float len = length(l.xy);
    vec2 dir = len > 0.00001 ? l.xy / len : vec2(0.0);
    vec2 uv = 0.5 + (theta / uHalfFov) * rot2(dir, cs) * circle;
    if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) return vec3(0.0);
    return vec3(uv, clamp((uHalfFov - theta) / uBlend, 0.001, 1.0));
}

vec3 gapColor(vec3 d) {
    float lon = atan(d.x, -d.z);
    float lat = asin(clamp(d.y, -1.0, 1.0));
    float cell = 0.2617994;
    float gl = abs(fract(lon / cell + 0.5) - 0.5);
    float gt = abs(fract(lat / cell + 0.5) - 0.5);
    float line = 1.0 - smoothstep(0.0, 0.035, min(gl, gt));
    return mix(vec3(0.055, 0.075, 0.115), vec3(0.17, 0.21, 0.28), line);
}

vec4 shade(vec3 d) {
    vec3 lr = vec3(d.x, d.y, -d.z);
    vec3 lf = vec3(-d.x * uMirrorFront, d.y, d.z);
    vec3 a;
    vec3 b;
    if (uFisheye == 1) {
        a = mapFisheye(lr, uRotRear, uCircleRear);
        b = mapFisheye(lf, uRotFront, uCircleFront);
    } else {
        a = mapNormal(lr, uRotRear, uTanRear);
        b = mapNormal(lf, uRotFront, uTanFront);
    }
    vec3 cr = vec3(0.0);
    vec3 cf = vec3(0.0);
    if (a.z > 0.0) cr = texture2D(uRear, (uStRear * vec4(a.xy, 0.0, 1.0)).xy).rgb;
    if (b.z > 0.0) cf = texture2D(uFront, (uStFront * vec4(b.xy, 0.0, 1.0)).xy).rgb;
    float ws = a.z + b.z;
    if (ws <= 0.0) return vec4(gapColor(d), 1.0);
    return vec4((cr * a.z + cf * b.z) / ws, 1.0);
}
"""

    val SCREEN_FRAGMENT = COMMON + """
uniform mat4 uInvView;
uniform vec2 uTanView;
void main() {
    vec3 d = normalize((uInvView * vec4(vNdc.x * uTanView.x, vNdc.y * uTanView.y, -1.0, 0.0)).xyz);
    gl_FragColor = shade(d);
}
"""

    val EQUIRECT_FRAGMENT = COMMON + """
void main() {
    float lon = vNdc.x * 3.14159265;
    float lat = vNdc.y * 1.57079633;
    vec3 d = vec3(cos(lat) * sin(lon), sin(lat), -cos(lat) * cos(lon));
    gl_FragColor = shade(d);
}
"""
}
