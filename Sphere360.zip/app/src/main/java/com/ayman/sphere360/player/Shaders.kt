package com.ayman.sphere360.player

/**
 * One shading function, two entry points: the on-screen viewer and the equirectangular
 * 360 photo export. The video mapping mirrors SphereMath so coverage numbers match.
 *
 * Frames: "view" = what you look around in (Y up). uViewToWorld turns it into the Android
 * world frame (Z up, Y north). uWorldToDev turns that into the phone's frame at recording
 * start, which is where the cameras point.
 */
object Shaders {

    const val VERTEX = """
attribute vec2 aPos;
varying vec2 vNdc;
void main() {
    vNdc = aPos;
    gl_Position = vec4(aPos, 0.0, 1.0);
}
"""

    private const val COMMON = """#extension GL_OES_EGL_image_external : require
precision highp float;
varying vec2 vNdc;
uniform samplerExternalOES uRear;
uniform samplerExternalOES uFront;
uniform sampler2D uBg;
uniform mat4 uStRear;
uniform mat4 uStFront;
uniform mat4 uViewToWorld;
uniform mat4 uWorldToDev;
uniform int uFisheye;
uniform int uFill;
uniform vec2 uRotRear;
uniform vec2 uRotFront;
uniform vec2 uTanRear;
uniform vec2 uTanFront;
uniform vec2 uCircleRear;
uniform vec2 uCircleFront;
uniform float uHalfFov;
uniform float uBlend;
uniform float uMirrorFront;
uniform float uEdge;
uniform float uHasBg;
uniform float uBgYaw;
uniform vec2 uStretch;

// Squeezes each camera's half of the world so the rear view fills the front 180 degrees
// and the front view fills the back 180 degrees. Not true geometry: labelled in the app.
vec3 warp(vec3 dv) {
    float lon = atan(dv.x, -dv.z);
    float lat = asin(clamp(dv.y, -1.0, 1.0));
    if (abs(lon) <= 1.5707963) {
        lon = lon / uStretch.x;
    } else {
        float b = lon > 0.0 ? 3.14159265 : -3.14159265;
        lon = b + (lon - b) / uStretch.y;
    }
    return vec3(cos(lat) * sin(lon), sin(lat), -cos(lat) * cos(lon));
}

vec2 rot2(vec2 p, vec2 cs) {
    return vec2(p.x * cs.x - p.y * cs.y, p.x * cs.y + p.y * cs.x);
}

float edgeFeather(vec2 uv) {
    float e = min(min(uv.x, 1.0 - uv.x), min(uv.y, 1.0 - uv.y));
    return uEdge > 0.0 ? clamp(e / uEdge, 0.0, 1.0) : 1.0;
}

vec3 mapNormal(vec3 l, vec2 cs, vec2 tanHalf) {
    if (l.z <= 0.001) return vec3(0.0);
    vec2 p = rot2(l.xy / l.z, cs);
    vec2 uv = 0.5 + 0.5 * p / tanHalf;
    if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) return vec3(0.0);
    return vec3(uv, max(edgeFeather(uv), 0.001));
}

vec3 mapFisheye(vec3 l, vec2 cs, vec2 circle) {
    float theta = acos(clamp(l.z, -1.0, 1.0));
    if (theta > uHalfFov) return vec3(0.0);
    float len = length(l.xy);
    vec2 dir = len > 0.00001 ? l.xy / len : vec2(0.0);
    vec2 uv = 0.5 + (theta / uHalfFov) * rot2(dir, cs) * circle;
    if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) return vec3(0.0);
    return vec3(uv, clamp((uHalfFov - theta) / uBlend, 0.001, 1.0));
}

vec3 gapColor(vec3 d) {
    float lon = atan(d.x, -d.z);
    float lat = asin(clamp(d.y, -1.0, 1.0));
    float cell = 0.2617994;
    float gl = abs(fract(lon / cell + 0.5) - 0.5);
    float gt = abs(fract(lat / cell + 0.5) - 0.5);
    float line = 1.0 - smoothstep(0.0, 0.035, min(gl, gt));
    return mix(vec3(0.055, 0.075, 0.115), vec3(0.17, 0.21, 0.28), line);
}

// Soft fill: a blurred average of the nearest video edge, fading to dark. Not real footage.
vec3 edgeRear(vec2 uc) {
    vec3 c = texture2D(uRear, (uStRear * vec4(uc, 0.0, 1.0)).xy).rgb;
    c += texture2D(uRear, (uStRear * vec4(clamp(uc + vec2(0.1, 0.0), 0.0, 1.0), 0.0, 1.0)).xy).rgb;
    c += texture2D(uRear, (uStRear * vec4(clamp(uc - vec2(0.1, 0.0), 0.0, 1.0), 0.0, 1.0)).xy).rgb;
    c += texture2D(uRear, (uStRear * vec4(clamp(uc + vec2(0.0, 0.1), 0.0, 1.0), 0.0, 1.0)).xy).rgb;
    c += texture2D(uRear, (uStRear * vec4(clamp(uc - vec2(0.0, 0.1), 0.0, 1.0), 0.0, 1.0)).xy).rgb;
    return c / 5.0;
}

vec3 edgeFront(vec2 uc) {
    vec3 c = texture2D(uFront, (uStFront * vec4(uc, 0.0, 1.0)).xy).rgb;
    c += texture2D(uFront, (uStFront * vec4(clamp(uc + vec2(0.1, 0.0), 0.0, 1.0), 0.0, 1.0)).xy).rgb;
    c += texture2D(uFront, (uStFront * vec4(clamp(uc - vec2(0.1, 0.0), 0.0, 1.0), 0.0, 1.0)).xy).rgb;
    c += texture2D(uFront, (uStFront * vec4(clamp(uc + vec2(0.0, 0.1), 0.0, 1.0), 0.0, 1.0)).xy).rgb;
    c += texture2D(uFront, (uStFront * vec4(clamp(uc - vec2(0.0, 0.1), 0.0, 1.0), 0.0, 1.0)).xy).rgb;
    return c / 5.0;
}

vec3 softFill(vec3 lr, vec3 lf) {
    vec3 acc = vec3(0.05, 0.06, 0.08) * 0.35;
    float wsum = 0.35;
    if (lr.z > 0.0) {
        vec2 uv = 0.5 + 0.5 * rot2(lr.xy / max(lr.z, 0.05), uRotRear) / uTanRear;
        vec2 uc = clamp(uv, 0.06, 0.94);
        float w = exp(-length(uv - uc) * 3.5);
        acc += edgeRear(uc) * w;
        wsum += w;
    }
    if (lf.z > 0.0) {
        vec2 uv = 0.5 + 0.5 * rot2(lf.xy / max(lf.z, 0.05), uRotFront) / uTanFront;
        vec2 uc = clamp(uv, 0.06, 0.94);
        float w = exp(-length(uv - uc) * 3.5);
        acc += edgeFront(uc) * w;
        wsum += w;
    }
    vec3 c = acc / wsum;
    float g = dot(c, vec3(0.299, 0.587, 0.114));
    return mix(vec3(g), c, 0.5) * 0.75;
}

vec4 bgSample(vec3 w) {
    float c = cos(uBgYaw);
    float s = sin(uBgYaw);
    vec3 r = vec3(w.x * c - w.y * s, w.x * s + w.y * c, w.z);
    float lon = atan(r.x, r.y);
    float lat = asin(clamp(r.z, -1.0, 1.0));
    vec4 t = texture2D(uBg, vec2(lon / 6.2831853 + 0.5, 0.5 - lat / 3.14159265));
    if (t.a > 0.004) t.rgb = t.rgb / t.a;
    return t;
}

vec4 shade(vec3 dv) {
    vec3 w = (uViewToWorld * vec4(dv, 0.0)).xyz;
    vec3 wv = (uViewToWorld * vec4(warp(dv), 0.0)).xyz;
    vec3 d = (uWorldToDev * vec4(wv, 0.0)).xyz;
    vec3 lr = vec3(d.x, d.y, -d.z);
    vec3 lf = vec3(-d.x * uMirrorFront, d.y, d.z);
    vec3 a;
    vec3 b;
    if (uFisheye == 1) {
        a = mapFisheye(lr, uRotRear, uCircleRear);
        b = mapFisheye(lf, uRotFront, uCircleFront);
    } else {
        a = mapNormal(lr, uRotRear, uTanRear);
        b = mapNormal(lf, uRotFront, uTanFront);
    }
    vec3 cr = vec3(0.0);
    vec3 cf = vec3(0.0);
    if (a.z > 0.0) cr = texture2D(uRear, (uStRear * vec4(a.xy, 0.0, 1.0)).xy).rgb;
    if (b.z > 0.0) cf = texture2D(uFront, (uStFront * vec4(b.xy, 0.0, 1.0)).xy).rgb;
    float ws = a.z + b.z;
    vec3 video = ws > 0.0 ? (cr * a.z + cf * b.z) / ws : vec3(0.0);
    float alpha = clamp(ws, 0.0, 1.0);
    if (alpha >= 0.999) return vec4(video, 1.0);
    vec3 fill;
    if (uFill == 0) {
        fill = gapColor(dv);
    } else {
        fill = softFill(lr, lf);
        if (uFill == 2 && uHasBg > 0.5) {
            vec4 bg = bgSample(w);
            fill = mix(fill, bg.rgb, clamp(bg.a, 0.0, 1.0));
        }
    }
    return vec4(mix(fill, video, alpha), 1.0);
}
"""

    val SCREEN_FRAGMENT = COMMON + """
uniform mat4 uInvView;
uniform vec2 uTanView;
void main() {
    vec3 d = normalize((uInvView * vec4(vNdc.x * uTanView.x, vNdc.y * uTanView.y, -1.0, 0.0)).xyz);
    gl_FragColor = shade(d);
}
"""

    val EQUIRECT_FRAGMENT = COMMON + """
void main() {
    float lon = vNdc.x * 3.14159265;
    float lat = vNdc.y * 1.57079633;
    vec3 d = vec3(cos(lat) * sin(lon), sin(lat), -cos(lat) * cos(lon));
    gl_FragColor = shade(d);
}
"""

    // ---------------------------------------------------------------- room scan

    /** Paints the live camera frame into the world-fixed equirectangular canvas. */
    const val SCAN_PAINT = """#extension GL_OES_EGL_image_external : require
precision highp float;
varying vec2 vNdc;
uniform samplerExternalOES uCam;
uniform mat4 uSt;
uniform mat4 uWorldToDev;
uniform vec2 uRot;
uniform vec2 uTan;
void main() {
    float lon = vNdc.x * 3.14159265;
    float lat = vNdc.y * 1.57079633;
    vec3 w = vec3(cos(lat) * sin(lon), cos(lat) * cos(lon), sin(lat));
    vec3 dd = (uWorldToDev * vec4(w, 0.0)).xyz;
    vec3 l = vec3(dd.x, dd.y, -dd.z);
    if (l.z <= 0.01) discard;
    vec2 p = l.xy / l.z;
    p = vec2(p.x * uRot.x - p.y * uRot.y, p.x * uRot.y + p.y * uRot.x);
    vec2 uv = 0.5 + 0.5 * p / uTan;
    if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) discard;
    float e = min(min(uv.x, 1.0 - uv.x), min(uv.y, 1.0 - uv.y));
    float a = smoothstep(0.0, 0.12, e) * 0.6;
    vec3 c = texture2D(uCam, (uSt * vec4(uv, 0.0, 1.0)).xy).rgb;
    gl_FragColor = vec4(c, a);
}
"""

    const val SCAN_CAMERA = """#extension GL_OES_EGL_image_external : require
precision mediump float;
varying vec2 vNdc;
uniform samplerExternalOES uCam;
uniform mat4 uSt;
uniform vec2 uScale;
void main() {
    vec2 uv = 0.5 + 0.5 * vNdc * uScale;
    gl_FragColor = texture2D(uCam, (uSt * vec4(uv, 0.0, 1.0)).xy);
}
"""

    const val SCAN_PANO = """precision mediump float;
varying vec2 vNdc;
uniform sampler2D uCanvas;
uniform vec2 uMarker;
uniform float uHasMarker;
void main() {
    vec2 uv = vNdc * 0.5 + 0.5;
    vec4 c = texture2D(uCanvas, uv);
    vec3 rgb = c.a > 0.004 ? c.rgb / c.a : vec3(0.0);
    float gx = step(0.94, fract(uv.x * 24.0));
    float gy = step(0.88, fract(uv.y * 12.0));
    vec3 empty = mix(vec3(0.07, 0.09, 0.14), vec3(0.16, 0.2, 0.28), max(gx, gy));
    vec3 col = mix(empty, rgb, clamp(c.a, 0.0, 1.0));
    if (uHasMarker > 0.5) {
        vec2 d = (uv - uMarker) * vec2(2.0, 1.0);
        float ring = 1.0 - smoothstep(0.006, 0.012, abs(length(d) - 0.035));
        col = mix(col, vec3(0.95, 0.66, 0.23), ring);
    }
    gl_FragColor = vec4(col, 1.0);
}
"""
}
