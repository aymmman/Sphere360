package com.ayman.sphere360.data

import android.content.Context
import android.os.Environment
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class LensMode { NORMAL, FISHEYE }

/** How areas the cameras didn't see are drawn. */
enum class FillMode { GRID, SOFT, BACKGROUND }

/** What one camera recorded. hFovDeg is measured along the long side of the video frame. */
data class CamMeta(
    val cameraId: String,
    val sensorOrientation: Int,
    val hFovDeg: Float,
    val width: Int,
    val height: Int,
    val zoom: Float
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("cameraId", cameraId)
        put("sensorOrientation", sensorOrientation)
        put("hFovDeg", hFovDeg.toDouble())
        put("width", width)
        put("height", height)
        put("zoom", zoom.toDouble())
    }

    companion object {
        fun fromJson(o: JSONObject) = CamMeta(
            cameraId = o.getString("cameraId"),
            sensorOrientation = o.getInt("sensorOrientation"),
            hFovDeg = o.getDouble("hFovDeg").toFloat(),
            width = o.getInt("width"),
            height = o.getInt("height"),
            zoom = o.optDouble("zoom", 1.0).toFloat()
        )
    }
}

/** User adjustments made in the player. Stored with the recording. */
data class Calibration(
    val mode: LensMode,
    val rearQuarter: Int = 0,
    val frontQuarter: Int = 0,
    val mirrorFront: Boolean = false,
    val fisheyeFovDeg: Float = 190f,
    val circleScale: Float = 1f,
    val blendDeg: Float = 6f,
    val fill: FillMode = FillMode.SOFT,
    val bgYawDeg: Float = 0f,
    val useOrientation: Boolean = true,
    /** 0 = true geometry, 1 = each camera stretched sideways so the two views meet. */
    val stretch: Float = 1f
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("mode", mode.name)
        put("rearQuarter", rearQuarter)
        put("frontQuarter", frontQuarter)
        put("mirrorFront", mirrorFront)
        put("fisheyeFovDeg", fisheyeFovDeg.toDouble())
        put("circleScale", circleScale.toDouble())
        put("blendDeg", blendDeg.toDouble())
        put("fill", fill.name)
        put("bgYawDeg", bgYawDeg.toDouble())
        put("useOrientation", useOrientation)
        put("stretch", stretch.toDouble())
    }

    companion object {
        fun fromJson(o: JSONObject?, fallback: LensMode): Calibration {
            if (o == null) return Calibration(fallback)
            return Calibration(
                mode = runCatching { LensMode.valueOf(o.getString("mode")) }.getOrDefault(fallback),
                rearQuarter = o.optInt("rearQuarter", 0),
                frontQuarter = o.optInt("frontQuarter", 0),
                mirrorFront = o.optBoolean("mirrorFront", false),
                fisheyeFovDeg = o.optDouble("fisheyeFovDeg", 190.0).toFloat(),
                circleScale = o.optDouble("circleScale", 1.0).toFloat(),
                blendDeg = o.optDouble("blendDeg", 6.0).toFloat(),
                fill = runCatching { FillMode.valueOf(o.getString("fill")) }.getOrDefault(FillMode.SOFT),
                bgYawDeg = o.optDouble("bgYawDeg", 0.0).toFloat(),
                useOrientation = o.optBoolean("useOrientation", true),
                stretch = o.optDouble("stretch", 1.0).toFloat()
            )
        }
    }
}

data class Session(
    val dir: File,
    val createdAt: Long,
    val durationMs: Long,
    val lensMode: LensMode,
    val rear: CamMeta,
    val front: CamMeta,
    /** Front first frame time minus rear first frame time, measured from sensor timestamps. */
    val frontOffsetMs: Long,
    val fpsRear: Float,
    val fpsFront: Float,
    val droppedRear: Int,
    val droppedFront: Int,
    val hasAudio: Boolean,
    val complete: Boolean,
    val calibration: Calibration,
    /** Phone orientation when recording started: 16 floats, OpenGL world-to-device matrix. */
    val orientation: FloatArray? = null,
    /** Share of the sphere covered by the room scan copied into this recording (0 if none). */
    val bgCoverage: Float = 0f
) {
    val rearFile: File get() = File(dir, REAR)
    val frontFile: File get() = File(dir, FRONT)
    val backgroundFile: File get() = File(dir, BACKGROUND)
    val hasBackground: Boolean get() = backgroundFile.exists()
    val sizeBytes: Long get() = dir.listFiles()?.sumOf { it.length() } ?: 0L

    fun toJson(): JSONObject = JSONObject().apply {
        put("version", 2)
        put("createdAt", createdAt)
        put("durationMs", durationMs)
        put("lensMode", lensMode.name)
        put("rear", rear.toJson())
        put("front", front.toJson())
        put("frontOffsetMs", frontOffsetMs)
        put("fpsRear", fpsRear.toDouble())
        put("fpsFront", fpsFront.toDouble())
        put("droppedRear", droppedRear)
        put("droppedFront", droppedFront)
        put("hasAudio", hasAudio)
        put("complete", complete)
        put("calibration", calibration.toJson())
        orientation?.let { m -> put("orientation", JSONArray().apply { m.forEach { put(it.toDouble()) } }) }
        put("bgCoverage", bgCoverage.toDouble())
    }

    companion object {
        const val REAR = "rear.mp4"
        const val FRONT = "front.mp4"
        const val BACKGROUND = "background.png"

        fun fromJson(dir: File, o: JSONObject): Session {
            val mode = runCatching { LensMode.valueOf(o.getString("lensMode")) }.getOrDefault(LensMode.NORMAL)
            val orient = o.optJSONArray("orientation")?.let { arr ->
                if (arr.length() == 16) FloatArray(16) { arr.getDouble(it).toFloat() } else null
            }
            return Session(
                dir = dir,
                createdAt = o.optLong("createdAt", dir.lastModified()),
                durationMs = o.optLong("durationMs", 0L),
                lensMode = mode,
                rear = CamMeta.fromJson(o.getJSONObject("rear")),
                front = CamMeta.fromJson(o.getJSONObject("front")),
                frontOffsetMs = o.optLong("frontOffsetMs", 0L),
                fpsRear = o.optDouble("fpsRear", 0.0).toFloat(),
                fpsFront = o.optDouble("fpsFront", 0.0).toFloat(),
                droppedRear = o.optInt("droppedRear", 0),
                droppedFront = o.optInt("droppedFront", 0),
                hasAudio = o.optBoolean("hasAudio", false),
                complete = o.optBoolean("complete", false),
                calibration = Calibration.fromJson(o.optJSONObject("calibration"), mode),
                orientation = orient,
                bgCoverage = o.optDouble("bgCoverage", 0.0).toFloat()
            )
        }
    }
}

/** Recordings live in app-private storage: Android/data/<app>/files/Movies/sessions/<timestamp>/ */
object SessionRepository {
    private const val META = "session.json"

    fun root(context: Context): File {
        val base = context.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: File(context.filesDir, "movies")
        return File(base, "sessions").apply { mkdirs() }
    }

    fun newSessionDir(context: Context): File {
        val name = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val root = root(context)
        var dir = File(root, name)
        var i = 1
        while (dir.exists()) dir = File(root, "${name}_${i++}")
        dir.mkdirs()
        return dir
    }

    fun save(session: Session) {
        val tmp = File(session.dir, "$META.tmp")
        tmp.writeText(session.toJson().toString(2))
        tmp.renameTo(File(session.dir, META))
    }

    fun load(dir: File): Session? = runCatching {
        Session.fromJson(dir, JSONObject(File(dir, META).readText()))
    }.getOrNull()

    fun list(context: Context): List<Session> =
        root(context).listFiles()
            ?.filter { it.isDirectory }
            ?.mapNotNull { load(it) }
            ?.sortedByDescending { it.createdAt }
            ?: emptyList()

    fun delete(session: Session): Boolean = session.dir.deleteRecursively()
}
