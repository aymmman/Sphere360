package com.ayman.sphere360.player

import android.graphics.Bitmap
import android.graphics.Rect
import android.graphics.SurfaceTexture
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.util.Log
import com.ayman.sphere360.geometry.SphereMath
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

/**
 * Room scan: every camera frame is projected onto a world-fixed 360 canvas using the
 * phone's orientation, so turning around slowly fills in the whole sphere with real pixels.
 */
class ScanRenderer(
    private val onCameraTexture: (SurfaceTexture) -> Unit,
    private val onError: (String) -> Unit
) : GLSurfaceView.Renderer {

    @Volatile var painting = false
    @Volatile var worldToDev: FloatArray? = null
    @Volatile var lens: SphereMath.Lens? = null
    /** Where to draw the panorama, in window pixels. */
    @Volatile var panoRect: Rect? = null
    /** Upright camera image aspect (width / height) for the live preview. */
    @Volatile var previewAspect = 9f / 16f

    @Volatile private var resetRequested = true
    @Volatile private var readCallback: ((Bitmap?) -> Unit)? = null

    private var paintProg = 0
    private var camProg = 0
    private var panoProg = 0
    private val camTex = IntArray(1)
    private val canvasTex = IntArray(1)
    private val fbo = IntArray(1)
    private var st: SurfaceTexture? = null
    private val stM = FloatArray(16)
    private var vw = 1
    private var vh = 1

    private val quad: FloatBuffer = ByteBuffer.allocateDirect(8 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
        put(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f))
        position(0)
    }

    fun reset() { resetRequested = true }

    fun requestCanvas(callback: (Bitmap?) -> Unit) { readCallback = callback }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        try {
            paintProg = GlUtil.program(Shaders.VERTEX, Shaders.SCAN_PAINT)
            camProg = GlUtil.program(Shaders.VERTEX, Shaders.SCAN_CAMERA)
            panoProg = GlUtil.program(Shaders.VERTEX, Shaders.SCAN_PANO)
        } catch (e: Exception) {
            Log.e(TAG, "shader error", e)
            onError("Graphics setup failed: ${e.message}")
            return
        }
        GLES20.glGenTextures(1, camTex, 0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, camTex[0])
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)

        GLES20.glGenTextures(1, canvasTex, 0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, canvasTex[0])
        GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, CANVAS_W, CANVAS_H, 0, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, null)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_REPEAT)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glGenFramebuffers(1, fbo, 0)
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fbo[0])
        GLES20.glFramebufferTexture2D(GLES20.GL_FRAMEBUFFER, GLES20.GL_COLOR_ATTACHMENT0, GLES20.GL_TEXTURE_2D, canvasTex[0], 0)
        if (GLES20.glCheckFramebufferStatus(GLES20.GL_FRAMEBUFFER) != GLES20.GL_FRAMEBUFFER_COMPLETE) {
            onError("Graphics setup failed: canvas not supported")
        }
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
        resetRequested = true

        runCatching { st?.release() }
        val s = SurfaceTexture(camTex[0])
        st = s
        Matrix.setIdentityM(stM, 0)
        onCameraTexture(s)
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        vw = width.coerceAtLeast(1)
        vh = height.coerceAtLeast(1)
    }

    override fun onDrawFrame(gl: GL10?) {
        if (paintProg == 0) return
        runCatching { st?.updateTexImage(); st?.getTransformMatrix(stM) }

        if (resetRequested) {
            resetRequested = false
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fbo[0])
            GLES20.glViewport(0, 0, CANVAS_W, CANVAS_H)
            GLES20.glClearColor(0f, 0f, 0f, 0f)
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        }

        val m = worldToDev
        val l = lens
        if (painting && m != null && l != null) {
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fbo[0])
            GLES20.glViewport(0, 0, CANVAS_W, CANVAS_H)
            GLES20.glEnable(GLES20.GL_BLEND)
            GLES20.glBlendFuncSeparate(
                GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA,
                GLES20.GL_ONE, GLES20.GL_ONE_MINUS_SRC_ALPHA
            )
            GLES20.glUseProgram(paintProg)
            bindCam(paintProg)
            GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(paintProg, "uWorldToDev"), 1, false, m, 0)
            val a = Math.toRadians(l.rotDeg.toDouble())
            GLES20.glUniform2f(GLES20.glGetUniformLocation(paintProg, "uRot"), cos(a).toFloat(), sin(a).toFloat())
            GLES20.glUniform2f(GLES20.glGetUniformLocation(paintProg, "uTan"), l.tanW, l.tanH)
            drawQuad(paintProg)
            GLES20.glDisable(GLES20.GL_BLEND)
        }

        readCallback?.let { cb ->
            readCallback = null
            cb(runCatching { readCanvas() }.onFailure { Log.e(TAG, "read failed", it) }.getOrNull())
        }

        // Screen: live camera underneath, panorama on top.
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
        GLES20.glViewport(0, 0, vw, vh)
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        GLES20.glUseProgram(camProg)
        bindCam(camProg)
        val screenAspect = vw.toFloat() / vh
        val sx: Float
        val sy: Float
        if (screenAspect < previewAspect) { sx = screenAspect / previewAspect; sy = 1f } else { sx = 1f; sy = previewAspect / screenAspect }
        GLES20.glUniform2f(GLES20.glGetUniformLocation(camProg, "uScale"), sx, sy)
        drawQuad(camProg)

        panoRect?.let { r ->
            GLES20.glViewport(r.left, vh - r.bottom, r.width(), r.height())
            GLES20.glUseProgram(panoProg)
            GLES20.glActiveTexture(GLES20.GL_TEXTURE1)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, canvasTex[0])
            GLES20.glUniform1i(GLES20.glGetUniformLocation(panoProg, "uCanvas"), 1)
            if (m != null) {
                // Camera axis (device -Z) in world: minus the third column of device-to-world.
                val ax = -m[2]; val ay = -m[6]; val az = -m[10]
                val lon = atan2(ax, ay)
                val lat = asin(az.coerceIn(-1f, 1f))
                GLES20.glUniform2f(
                    GLES20.glGetUniformLocation(panoProg, "uMarker"),
                    (lon / (2 * Math.PI) + 0.5).toFloat(), (lat / Math.PI + 0.5).toFloat()
                )
                GLES20.glUniform1f(GLES20.glGetUniformLocation(panoProg, "uHasMarker"), 1f)
            } else {
                GLES20.glUniform1f(GLES20.glGetUniformLocation(panoProg, "uHasMarker"), 0f)
            }
            drawQuad(panoProg)
            GLES20.glViewport(0, 0, vw, vh)
        }
    }

    private fun bindCam(program: Int) {
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, camTex[0])
        GLES20.glUniform1i(GLES20.glGetUniformLocation(program, "uCam"), 0)
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(program, "uSt"), 1, false, stM, 0)
    }

    private fun drawQuad(program: Int) {
        val loc = GLES20.glGetAttribLocation(program, "aPos")
        quad.position(0)
        GLES20.glEnableVertexAttribArray(loc)
        GLES20.glVertexAttribPointer(loc, 2, GLES20.GL_FLOAT, false, 0, quad)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(loc)
    }

    private fun readCanvas(): Bitmap {
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fbo[0])
        val buf = ByteBuffer.allocateDirect(CANVAS_W * CANVAS_H * 4).order(ByteOrder.nativeOrder())
        GLES20.glReadPixels(0, 0, CANVAS_W, CANVAS_H, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, buf)
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
        buf.rewind()
        val raw = Bitmap.createBitmap(CANVAS_W, CANVAS_H, Bitmap.Config.ARGB_8888)
        raw.copyPixelsFromBuffer(buf)
        val flip = android.graphics.Matrix().apply { preScale(1f, -1f) }
        val out = Bitmap.createBitmap(raw, 0, 0, CANVAS_W, CANVAS_H, flip, false)
        if (out != raw) raw.recycle()
        return out
    }

    fun releaseGl() {
        runCatching { st?.release() }
        st = null
        GLES20.glDeleteFramebuffers(1, fbo, 0)
        GLES20.glDeleteTextures(1, canvasTex, 0)
        GLES20.glDeleteTextures(1, camTex, 0)
        listOf(paintProg, camProg, panoProg).forEach { if (it != 0) GLES20.glDeleteProgram(it) }
        paintProg = 0; camProg = 0; panoProg = 0
    }

    companion object {
        private const val TAG = "ScanRenderer"
        const val CANVAS_W = 2048
        const val CANVAS_H = 1024
    }
}
