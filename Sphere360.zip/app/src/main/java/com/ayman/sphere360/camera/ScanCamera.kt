package com.ayman.sphere360.camera

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.params.OutputConfiguration
import android.hardware.camera2.params.SessionConfiguration
import android.os.Handler
import android.os.HandlerThread
import android.view.Surface
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.concurrent.Executor
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** Rear camera only, at its widest view, feeding the room scan. */
class ScanCamera(context: Context) {

    data class Info(val hFovDeg: Float, val sensorOrientation: Int, val width: Int, val height: Int)

    private val mgr = context.getSystemService(CameraManager::class.java)
    private val thread = HandlerThread("ScanCamera").apply { start() }
    private val handler = Handler(thread.looper)
    private val executor = Executor { handler.post(it) }
    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var surface: Surface? = null

    private fun pickRear(): String {
        CameraProbe.findFrontBackPair(mgr)?.let { return it.first }
        return mgr.cameraIdList.firstOrNull {
            mgr.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
        } ?: throw CameraUnavailable("No rear camera found.")
    }

    suspend fun open(st: SurfaceTexture): Info {
        close()
        val id = pickRear()
        val ch = mgr.getCameraCharacteristics(id)
        val zoom = CameraProbe.minZoom(ch)
        val size = CameraProbe.choosePreviewSize(ch)
        st.setDefaultBufferSize(size.width, size.height)
        val s = Surface(st)
        surface = s
        val d = openDevice(id)
        device = d
        val cs = createSession(d, s)
        session = cs
        val b = d.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
        b.addTarget(s)
        CameraProbe.fps30(ch)?.let { b.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, it) }
        if (zoom != 1f) b.set(CaptureRequest.CONTROL_ZOOM_RATIO, zoom)
        b.set(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE, CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_OFF)
        cs.setRepeatingRequest(b.build(), null, handler)
        return Info(
            hFovDeg = CameraProbe.horizontalFovDeg(ch, zoom),
            sensorOrientation = ch.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90,
            width = size.width,
            height = size.height
        )
    }

    fun close() {
        runCatching { session?.close() }
        runCatching { device?.close() }
        runCatching { surface?.release() }
        session = null
        device = null
        surface = null
    }

    fun release() {
        close()
        thread.quitSafely()
    }

    @SuppressLint("MissingPermission")
    private suspend fun openDevice(id: String): CameraDevice = suspendCancellableCoroutine { cont ->
        mgr.openCamera(id, object : CameraDevice.StateCallback() {
            override fun onOpened(d: CameraDevice) {
                if (cont.isActive) cont.resume(d) else d.close()
            }
            override fun onDisconnected(d: CameraDevice) {
                d.close()
                if (cont.isActive) cont.resumeWithException(CameraUnavailable("The camera was taken by another app."))
            }
            override fun onError(d: CameraDevice, error: Int) {
                d.close()
                if (cont.isActive) cont.resumeWithException(CameraUnavailable("The camera failed to open (error $error)."))
            }
        }, handler)
    }

    private suspend fun createSession(d: CameraDevice, s: Surface): CameraCaptureSession =
        suspendCancellableCoroutine { cont ->
            d.createCaptureSession(SessionConfiguration(
                SessionConfiguration.SESSION_REGULAR, listOf(OutputConfiguration(s)), executor,
                object : CameraCaptureSession.StateCallback() {
                    override fun onConfigured(session: CameraCaptureSession) {
                        if (cont.isActive) cont.resume(session) else session.close()
                    }
                    override fun onConfigureFailed(session: CameraCaptureSession) {
                        if (cont.isActive) cont.resumeWithException(CameraUnavailable("The camera couldn't start."))
                    }
                }
            ))
        }
}
