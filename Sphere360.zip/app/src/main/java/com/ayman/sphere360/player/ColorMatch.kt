package com.ayman.sphere360.player

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import com.ayman.sphere360.data.Session
import com.ayman.sphere360.geometry.SphereMath
import java.io.File
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Measures how the room photo's colours differ from each camera's video in the places
 * they both show, and returns per-channel gains that pull the room photo towards the video.
 * Uses the same geometry as the shader, inverted.
 */
object ColorMatch {

    class Gains(val rear: FloatArray, val front: FloatArray, val samples: Int)

    private val ONE = floatArrayOf(1f, 1f, 1f)

    fun compute(session: Session, p: SphereRenderer.Params, bgYawRad: Float, mirrorFront: Boolean): Gains? {
        if (!session.hasBackground) return null
        val opts = BitmapFactory.Options().apply { inSampleSize = 4 }
        val bg = BitmapFactory.decodeFile(session.backgroundFile.absolutePath, opts) ?: return null
        try {
            val r = sample(session.rearFile, p.rear, true, p.worldToDev, bg, bgYawRad, mirrorFront)
            val f = sample(session.frontFile, p.front, false, p.worldToDev, bg, bgYawRad, mirrorFront)
            if (r == null && f == null) return null
            return Gains(r?.first ?: ONE, f?.first ?: ONE, (r?.second ?: 0) + (f?.second ?: 0))
        } finally {
            bg.recycle()
        }
    }

    private fun grabFrame(file: File): Bitmap? = runCatching {
        if (!file.exists()) return@runCatching null
        MediaMetadataRetriever().use { r ->
            r.setDataSource(file.absolutePath)
            r.getScaledFrameAtTime(1_000_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 128, 72)
        }
    }.getOrNull()

    private fun sample(
        file: File,
        lens: SphereMath.Lens,
        isRear: Boolean,
        worldToDev: FloatArray,
        bg: Bitmap,
        yaw: Float,
        mirrorFront: Boolean
    ): Pair<FloatArray, Int>? {
        val frame = grabFrame(file) ?: return null
        try {
            val fw = frame.width
            val fh = frame.height
            val bw = bg.width
            val bh = bg.height
            val a = Math.toRadians(-lens.rotDeg.toDouble())
            val ca = cos(a)
            val sa = sin(a)
            val cy = cos(yaw.toDouble())
            val sy = sin(yaw.toDouble())
            val m = if (mirrorFront) -1.0 else 1.0
            var vr = 0.0; var vg = 0.0; var vb = 0.0
            var br = 0.0; var bgr = 0.0; var bb = 0.0
            var n = 0
            for (y in 0 until fh) {
                for (x in 0 until fw) {
                    val u = (x + 0.5) / fw
                    val v = 1.0 - (y + 0.5) / fh
                    // Inverse of the shader's mapNormal.
                    val px = (2 * u - 1) * lens.tanW
                    val py = (2 * v - 1) * lens.tanH
                    var lx = px * ca - py * sa
                    var ly = px * sa + py * ca
                    var lz = 1.0
                    val len = sqrt(lx * lx + ly * ly + lz * lz)
                    lx /= len; ly /= len; lz /= len
                    val dx: Double; val dy: Double; val dz: Double
                    if (isRear) { dx = lx; dy = ly; dz = -lz } else { dx = -lx * m; dy = ly; dz = lz }
                    // world = deviceToWorld * d, where deviceToWorld(i, j) = worldToDev[i * 4 + j]
                    val wx = worldToDev[0] * dx + worldToDev[1] * dy + worldToDev[2] * dz
                    val wy = worldToDev[4] * dx + worldToDev[5] * dy + worldToDev[6] * dz
                    val wz = worldToDev[8] * dx + worldToDev[9] * dy + worldToDev[10] * dz
                    val rx = wx * cy - wy * sy
                    val ry = wx * sy + wy * cy
                    val lon = atan2(rx, ry)
                    val lat = asin(wz.coerceIn(-1.0, 1.0))
                    val bx = ((lon / (2 * Math.PI) + 0.5) * bw).toInt().coerceIn(0, bw - 1)
                    val by = ((0.5 - lat / Math.PI) * bh).toInt().coerceIn(0, bh - 1)
                    val bp = bg.getPixel(bx, by)
                    if ((bp ushr 24) < 200) continue
                    val vp = frame.getPixel(x, y)
                    vr += (vp shr 16) and 0xFF; vg += (vp shr 8) and 0xFF; vb += vp and 0xFF
                    br += (bp shr 16) and 0xFF; bgr += (bp shr 8) and 0xFF; bb += bp and 0xFF
                    n++
                }
            }
            if (n < 200 || br < 1 || bgr < 1 || bb < 1) return null
            val g = floatArrayOf(
                (vr / br).toFloat().coerceIn(0.5f, 2f),
                (vg / bgr).toFloat().coerceIn(0.5f, 2f),
                (vb / bb).toFloat().coerceIn(0.5f, 2f)
            )
            return g to n
        } finally {
            frame.recycle()
        }
    }
}
